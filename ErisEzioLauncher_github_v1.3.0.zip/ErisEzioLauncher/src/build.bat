@echo off
rem Compile Eris Ezio's Launcher (Go 1.21 ou plus requis : https://go.dev/dl/)
go build -ldflags "-s -w -H windowsgui" -o ErisEzioLauncher.exe .
if %errorlevel%==0 echo Compilation terminee : ErisEzioLauncher.exe
pause
