module erisezio-launcher

go 1.24
