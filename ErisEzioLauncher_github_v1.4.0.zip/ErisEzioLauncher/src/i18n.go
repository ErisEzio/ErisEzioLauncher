package main

import (
	"fmt"
	"strings"
)

// Langues de l'interface, dans l'ordre du menu.
var langues = []string{"fr", "en", "de", "it", "ru", "ja"}
var nomsLangues = []string{"Français", "English", "Deutsch", "Italiano", "Русский", "日本語"}

var langue = "fr"

func indiceLangue(l string) int {
	for i, x := range langues {
		if x == l {
			return i
		}
	}
	return 0
}

// Langue de Windows (GetUserDefaultUILanguage), anglais par défaut.
func langueSysteme() string {
	id, _, _ := kernel32.NewProc("GetUserDefaultUILanguage").Call()
	switch id & 0x3FF {
	case 0x0C:
		return "fr"
	case 0x07:
		return "de"
	case 0x10:
		return "it"
	case 0x19:
		return "ru"
	case 0x11:
		return "ja"
	}
	return "en"
}

// Format de date du sélecteur selon la langue.
func formatDate() string {
	switch langue {
	case "de", "ru":
		return "dd.MM.yyyy"
	case "ja":
		return "yyyy/MM/dd"
	}
	return "dd/MM/yyyy"
}

// Police de l'interface (le japonais a besoin d'une police dédiée).
func policeUI(semigras bool) string {
	if langue == "ja" {
		if semigras {
			return "Yu Gothic UI Semibold"
		}
		return "Yu Gothic UI"
	}
	if semigras {
		return "Segoe UI Semibold"
	}
	return "Segoe UI"
}

// Espace les lettres des gros titres (sauf en japonais).
func espace(s string) string {
	if langue == "ja" {
		return s
	}
	r := []rune(s)
	parts := make([]string, len(r))
	for i, c := range r {
		parts[i] = string(c)
	}
	return strings.Join(parts, " ")
}

// T renvoie le texte traduit (avec arguments à la manière de fmt.Sprintf).
func T(cle string, a ...any) string {
	t, ok := traductions[cle]
	if !ok {
		return cle
	}
	s := t[indiceLangue(langue)]
	if len(a) > 0 {
		return fmt.Sprintf(s, a...)
	}
	return s
}

// français, anglais, allemand, italien, russe, japonais
var traductions = map[string][6]string{
	"emu":      {"ÉMULATEUR", "EMULATOR", "EMULATOR", "EMULATORE", "ЭМУЛЯТОР", "エミュレーター"},
	"ecran":    {"ÉCRAN", "SCREEN", "BILDSCHIRM", "SCHERMO", "ЭКРАН", "画面"},
	"fen":      {"FENÊTRES", "WINDOWS", "FENSTER", "FINESTRE", "ОКНА", "ウィンドウ数"},
	"parligne": {"PAR LIGNE", "PER ROW", "PRO ZEILE", "PER RIGA", "В РЯДУ", "1行あたり"},
	"date":     {"DATE", "DATE", "DATUM", "DATA", "ДАТА", "日付"},
	"heure":    {"HEURE", "TIME", "UHRZEIT", "ORA", "ВРЕМЯ", "時刻"},
	"dispo":    {"DISPOSITION", "LAYOUT", "ANORDNUNG", "DISPOSIZIONE", "РАСКЛАДКА", "配置"},
	"rom":      {"ROM DU JEU", "GAME ROM", "SPIEL-ROM", "ROM DEL GIOCO", "ROM ИГРЫ", "ゲームROM"},
	"gba":      {"CARTOUCHE GBA", "GBA CARTRIDGE", "GBA-MODUL", "CARTUCCIA GBA", "КАРТРИДЖ GBA", "GBAカートリッジ"},
	"ecart":    {"ÉCART D'HORLOGE ENTRE FENÊTRES", "CLOCK OFFSET BETWEEN WINDOWS", "UHRZEIT-ABSTAND ZWISCHEN FENSTERN", "SCARTO DI ORARIO TRA FINESTRE", "СДВИГ ЧАСОВ МЕЖДУ ОКНАМИ", "ウィンドウ間の時刻差"},
	"u_s":      {"secondes", "seconds", "Sekunden", "secondi", "секунд", "秒"},
	"u_min":    {"minutes", "minutes", "Minuten", "minuti", "минут", "分"},
	"u_h":      {"heures", "hours", "Stunden", "ore", "часов", "時間"},
	"u_j":      {"jours", "days", "Tage", "giorni", "дней", "日"},
	"u_mois":   {"mois", "months", "Monate", "mesi", "месяцев", "か月"},
	"u_an":     {"années", "years", "Jahre", "anni", "лет", "年"},
	"sav":      {"SAUVEGARDE", "SAVE FILE", "SPIELSTAND", "SALVATAGGIO", "СОХРАНЕНИЕ", "セーブデータ"},

	"romVide": {"Aucune ROM — glisse un fichier ici.", "No ROM — drop a file here.", "Keine ROM – Datei hierher ziehen.",
		"Nessuna ROM — trascina qui un file.", "Нет ROM — перетащите файл сюда.", "ROMなし — ここにファイルをドロップ"},
	"gbaVide": {"Aucune cartouche GBA insérée.", "No GBA cartridge inserted.", "Kein GBA-Modul eingesteckt.",
		"Nessuna cartuccia GBA inserita.", "Картридж GBA не вставлен.", "GBAカートリッジが挿入されていません。"},
	"savVide": {"Sauvegarde par défaut du jeu.", "Game's default save file.", "Standard-Spielstand des Spiels.",
		"Salvataggio predefinito del gioco.", "Стандартное сохранение игры.", "ゲームの標準セーブデータ"},
	"savNon": {"Non disponible pour %s (sauvegardes internes).", "Not available for %s (internal saves).",
		"Für %s nicht verfügbar (interne Spielstände).", "Non disponibile per %s (salvataggi interni).",
		"Недоступно для %s (внутренние сохранения).", "%s では使用できません（内部セーブ）"},
	"savDsm": {"Sauvegarde par défaut (dossier Battery, .dsv).", "Default save (Battery folder, .dsv).",
		"Standard-Spielstand (Ordner Battery, .dsv).", "Salvataggio predefinito (cartella Battery, .dsv).",
		"Стандартное сохранение (папка Battery, .dsv).", "標準セーブ（Batteryフォルダー、.dsv）"},
	"decal": {"Décaler les lignes 2, 4… d'une demi-fenêtre", "Shift rows 2, 4… by half a window",
		"Zeilen 2, 4 … um ein halbes Fenster versetzen", "Sposta le righe 2, 4… di mezza finestra",
		"Сдвигать ряды 2, 4… на пол-окна", "2・4…行目を半ウィンドウずらす"},
	"auto": {"Auto · le plus grand", "Auto · largest", "Auto · größter", "Auto · il più grande", "Авто · самый большой", "自動・最大の画面"},

	"lancer":   {"LANCER", "LAUNCH", "STARTEN", "AVVIA", "ЗАПУСК", "起動"},
	"en cours": {"…", "…", "…", "…", "…", "…"},
	"resume": {"%d fenêtres  ·  horloges de %s à %s", "%d windows  ·  clocks from %s to %s", "%d Fenster  ·  Uhren von %s bis %s",
		"%d finestre  ·  orologi dalle %s alle %s", "Окон: %d  ·  часы с %s до %s", "%d ウィンドウ・時計 %s〜%s"},
	"arreter": {"ARRÊTER", "STOP", "STOPP", "FERMA", "СТОП", "停止"},
	"arreterSous": {"Clique pour stopper l'ouverture des fenêtres.", "Click to stop opening windows.",
		"Klicken, um das Öffnen der Fenster zu stoppen.", "Clicca per interrompere l'apertura delle finestre.",
		"Нажмите, чтобы остановить открытие окон.", "クリックでウィンドウの起動を停止"},
	"arretEnCours": {"ARRÊT EN COURS…", "STOPPING…", "WIRD GESTOPPT…", "ARRESTO IN CORSO…", "ОСТАНОВКА…", "停止中…"},
	"arretSous": {"Les fenêtres déjà ouvertes vont être rangées.", "Windows already open will be arranged.",
		"Bereits geöffnete Fenster werden angeordnet.", "Le finestre già aperte verranno sistemate.",
		"Уже открытые окна будут упорядочены.", "開いたウィンドウは整列されます"},

	"pret": {"Prêt — glisse une ROM ou une sauvegarde sur la fenêtre.", "Ready — drop a ROM or a save file on the window.",
		"Bereit – ROM oder Spielstand auf das Fenster ziehen.", "Pronto — trascina una ROM o un salvataggio sulla finestra.",
		"Готово — перетащите ROM или сохранение в окно.", "準備完了 — ROMまたはセーブをドロップ"},
	"savIgnoree": {"%s gère ses sauvegardes lui-même : sauvegarde ignorée.", "%s manages its own saves: save file ignored.",
		"%s verwaltet seine Spielstände selbst: Spielstand ignoriert.", "%s gestisce da sé i salvataggi: salvataggio ignorato.",
		"%s сам управляет сохранениями: файл пропущен.", "%s はセーブを自身で管理します：無視しました"},
	"savPrete": {"Sauvegarde prête : elle sera installée au prochain lancement.", "Save ready: it will be installed at the next launch.",
		"Spielstand bereit: wird beim nächsten Start installiert.", "Salvataggio pronto: verrà installato al prossimo avvio.",
		"Сохранение готово: будет установлено при следующем запуске.", "セーブ準備完了：次回起動時に適用されます"},
	"gbaOk":        {"Cartouche GBA insérée.", "GBA cartridge inserted.", "GBA-Modul eingesteckt.", "Cartuccia GBA inserita.", "Картридж GBA вставлен.", "GBAカートリッジを挿入しました"},
	"romOk":        {"ROM chargée.", "ROM loaded.", "ROM geladen.", "ROM caricata.", "ROM загружен.", "ROMを読み込みました"},
	"arretDemande": {"Arrêt demandé — la fenêtre en cours se termine…", "Stop requested — finishing the current window…", "Stopp angefordert – aktuelles Fenster wird abgeschlossen…", "Arresto richiesto — completamento della finestra in corso…", "Остановка запрошена — завершается текущее окно…", "停止を要求しました — 現在のウィンドウを完了中…"},
	"interrompu":   {"Lancement interrompu.", "Launch interrupted.", "Start abgebrochen.", "Avvio interrotto.", "Запуск прерван.", "起動を中断しました。"},
	"interrompuT":  {"Lancement interrompu", "Launch interrupted", "Start abgebrochen", "Avvio interrotto", "Запуск прерван", "起動を中断しました"},
	"savInstallee": {"Sauvegarde installée : %s", "Save installed: %s", "Spielstand installiert: %s", "Salvataggio installato: %s", "Сохранение установлено: %s", "セーブを適用しました：%s"},
	"savAncienne":  {" (ancienne gardée en %s)", " (old one kept as %s)", " (alter Stand gesichert als %s)", " (precedente conservato come %s)", " (старое сохранено как %s)", "（旧データ：%s）"},

	"radIntrouvT": {"RunAsDate introuvable", "RunAsDate not found", "RunAsDate nicht gefunden", "RunAsDate non trovato", "RunAsDate не найден", "RunAsDate が見つかりません"},
	"radIntrouv": {"Indique où se trouve RunAsDate.exe pour pouvoir lancer les fenêtres.", "Please locate RunAsDate.exe to launch the windows.",
		"Bitte RunAsDate.exe angeben, um die Fenster zu starten.", "Indica dove si trova RunAsDate.exe per avviare le finestre.",
		"Укажите, где находится RunAsDate.exe, чтобы запустить окна.", "ウィンドウを起動するには RunAsDate.exe の場所を指定してください。"},
	"emuIntrouvT": {"%s introuvable", "%s not found", "%s nicht gefunden", "%s non trovato", "%s не найден", "%s が見つかりません"},
	"emuIntrouv": {"Indique où se trouve l'exécutable de %s.", "Please locate the %s executable.", "Bitte die ausführbare Datei von %s angeben.",
		"Indica dove si trova l'eseguibile di %s.", "Укажите, где находится исполняемый файл %s.", "%s の実行ファイルの場所を指定してください。"},
	"savT":       {"Sauvegarde", "Save file", "Spielstand", "Salvataggio", "Сохранение", "セーブデータ"},
	"ouSeTrouve": {"Où se trouve %s ?", "Where is %s?", "Wo befindet sich %s?", "Dove si trova %s?", "Где находится %s?", "%s はどこにありますか？"},
	"exeDe":      {"l'exécutable de %s", "the %s executable", "die ausführbare Datei von %s", "l'eseguibile di %s", "исполняемый файл %s", "%s の実行ファイル"},
	"choisirRom": {"Choisir la ROM", "Choose the ROM", "ROM auswählen", "Scegli la ROM", "Выберите ROM", "ROMを選択"},
	"choisirGba": {"Choisir la cartouche GBA à insérer", "Choose the GBA cartridge to insert", "Einzusteckendes GBA-Modul auswählen", "Scegli la cartuccia GBA da inserire", "Выберите картридж GBA", "挿入するGBAカートリッジを選択"},
	"choisirSav": {"Choisir la sauvegarde", "Choose the save file", "Spielstand auswählen", "Scegli il salvataggio", "Выберите сохранение", "セーブデータを選択"},
	"fSav":       {"Sauvegardes", "Save files", "Spielstände", "Salvataggi", "Сохранения", "セーブデータ"},
	"fProg":      {"Programmes", "Programs", "Programme", "Programmi", "Программы", "プログラム"},
	"fTous":      {"Tous les fichiers", "All files", "Alle Dateien", "Tutti i file", "Все файлы", "すべてのファイル"},
	"detailLog": {"Le détail est dans ErisEzioLauncher.log, à côté du programme.", "Details are in ErisEzioLauncher.log, next to the program.",
		"Details stehen in ErisEzioLauncher.log neben dem Programm.", "I dettagli sono in ErisEzioLauncher.log, accanto al programma.",
		"Подробности — в ErisEzioLauncher.log рядом с программой.", "詳細はプログラムと同じ場所の ErisEzioLauncher.log にあります。"},
	"interne": {"Erreur interne", "Internal error", "Interner Fehler", "Errore interno", "Внутренняя ошибка", "内部エラー"},

	"fenetreN":  {"Fenêtre %d / %d  —  %s %s", "Window %d / %d  —  %s %s", "Fenster %d / %d  –  %s %s", "Finestra %d / %d  —  %s %s", "Окно %d / %d  —  %s %s", "ウィンドウ %d / %d — %s %s"},
	"rangement": {"Rangement final…", "Final arrangement…", "Abschließende Anordnung…", "Sistemazione finale…", "Финальная расстановка…", "最終整列中…"},
	"arretAucune": {"Arrêté : aucune fenêtre n'a été ouverte.", "Stopped: no window was opened.", "Gestoppt: kein Fenster wurde geöffnet.",
		"Interrotto: nessuna finestra è stata aperta.", "Остановлено: ни одно окно не открыто.", "停止：ウィンドウは開かれませんでした"},
	"aucuneDetectee": {"Aucune fenêtre %s n'a été détectée.", "No %s window was detected.", "Kein %s-Fenster erkannt.",
		"Nessuna finestra di %s rilevata.", "Окна %s не обнаружены.", "%s のウィンドウが検出されませんでした"},
	"arretN": {"Arrêté : %d fenêtre(s) ouverte(s) sur %d, rangées à leur place.", "Stopped: %d of %d window(s) opened and arranged.",
		"Gestoppt: %d von %d Fenster(n) geöffnet und angeordnet.", "Interrotto: %d finestra/e su %d aperte e sistemate.",
		"Остановлено: открыто и расставлено окон: %d из %d.", "停止：%d / %d ウィンドウを開いて整列しました"},
	"termine": {"Terminé : %d / %d fenêtres en %d ligne(s) de %d  ·  horloges de %s à %s.", "Done: %d / %d windows in %d row(s) of %d  ·  clocks from %s to %s.",
		"Fertig: %d / %d Fenster in %d Zeile(n) zu %d  ·  Uhren von %s bis %s.", "Fatto: %d / %d finestre in %d riga/e da %d  ·  orologi dalle %s alle %s.",
		"Готово: %d / %d окон, рядов: %d по %d  ·  часы с %s до %s.", "完了：%d / %d ウィンドウ（%d 行 × %d）・時計 %s〜%s"},
	"radAdmin": {"RunAsDate demande les droits administrateur : lance le launcher avec un clic droit > « Exécuter en tant qu'administrateur ».",
		"RunAsDate requires administrator rights: right-click the launcher > \"Run as administrator\".",
		"RunAsDate benötigt Administratorrechte: Rechtsklick auf den Launcher > „Als Administrator ausführen“.",
		"RunAsDate richiede i diritti di amministratore: clic destro sul launcher > «Esegui come amministratore».",
		"RunAsDate требует прав администратора: щёлкните по лаунчеру правой кнопкой > «Запуск от имени администратора».",
		"RunAsDate には管理者権限が必要です：ランチャーを右クリック >「管理者として実行」"},
	"radLance": {"Impossible de lancer RunAsDate : %s", "Unable to start RunAsDate: %s", "RunAsDate konnte nicht gestartet werden: %s",
		"Impossibile avviare RunAsDate: %s", "Не удалось запустить RunAsDate: %s", "RunAsDate を起動できません：%s"},

	"savRom": {"Choisis d'abord la ROM du jeu pour pouvoir utiliser cette sauvegarde.", "Choose the game ROM first to use this save file.",
		"Wähle zuerst die Spiel-ROM, um diesen Spielstand zu verwenden.", "Scegli prima la ROM del gioco per usare questo salvataggio.",
		"Сначала выберите ROM игры, чтобы использовать это сохранение.", "このセーブを使うには、先にゲームROMを選択してください。"},
	"savLire": {"Impossible de lire la sauvegarde : %s", "Unable to read the save file: %s", "Spielstand kann nicht gelesen werden: %s",
		"Impossibile leggere il salvataggio: %s", "Не удалось прочитать сохранение: %s", "セーブデータを読み込めません：%s"},
	"savDsmOnly": {"Pour DeSmuME, utilise une sauvegarde .dsv.\nUn .sav brut s'importe depuis DeSmuME : Fichier > Importer la mémoire de sauvegarde.",
		"For DeSmuME, use a .dsv save file.\nA raw .sav can be imported from DeSmuME: File > Import Backup Memory.",
		"Für DeSmuME einen .dsv-Spielstand verwenden.\nEine rohe .sav lässt sich in DeSmuME importieren: Datei > Sicherungsspeicher importieren.",
		"Per DeSmuME usa un salvataggio .dsv.\nUn .sav grezzo si importa da DeSmuME: File > Importa memoria di salvataggio.",
		"Для DeSmuME используйте сохранение .dsv.\nОбычный .sav импортируется в DeSmuME: Файл > Импорт резервной памяти.",
		"DeSmuME では .dsv セーブを使ってください。\n.sav は DeSmuME の「ファイル > バックアップメモリーのインポート」で取り込めます。"},
	"savCote": {"Impossible de mettre l'ancienne sauvegarde de côté : %s", "Unable to back up the old save file: %s",
		"Alter Spielstand konnte nicht gesichert werden: %s", "Impossibile mettere da parte il vecchio salvataggio: %s",
		"Не удалось сохранить резервную копию старого сохранения: %s", "旧セーブをバックアップできません：%s"},
	"savInst": {"Impossible d'installer la sauvegarde : %s", "Unable to install the save file: %s", "Spielstand konnte nicht installiert werden: %s",
		"Impossibile installare il salvataggio: %s", "Не удалось установить сохранение: %s", "セーブを適用できません：%s"},
}
