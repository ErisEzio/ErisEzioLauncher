-- =====================================================================
--  PECHE AUTO - Pokémon Noire / Blanche / Noire 2 / Blanche 2 (DeSmuME) - v4
--
--  En 5e génération, le jeu indique dans sa mémoire quand ça mord, quand
--  rien ne mord et quand un combat est en cours : le bot lit ces infos
--  directement (pas besoin de surveiller le « ! » à l'écran).
--
--  Fonctionnement :
--   - canne enregistrée sur Y ; place-toi face à l'eau et fais la
--     première pêche toi-même avec Y ;
--   - le bot ferre (A) dès que ça mord, ferme les messages d'échec et relance ;
--   - en combat, il attend. Y = le bot fuit pour toi (bouton FUITE).
--     Combat terminé (fuite, capture, K.O.) -> il relance la pêche ;
--   - SHINY : sauvegarde d'état (emplacement 9) dès la détection, pause sur
--     les étoiles, et le bot ne touche plus à rien (Y ne fait plus fuir).
--  Touche K (clavier) : mettre le bot en pause / le relancer.
--  Petit message en haut à droite de l'écran du bas.
--
--  Adresses mémoire d'après le projet libre pokebot-nds.
-- =====================================================================

local CONFIG = {
  Y_ECRAN_HAUT    = -192,  -- décalage de l'écran du haut (ne pas toucher)
  frames_appui    = 6,     -- durée d'un appui de touche
  delai_max       = 1800,  -- abandon d'une pêche sans résultat (30 s)
  fin_combat      = 90,    -- images hors combat avant de relancer la pêche
  bouton_fuite    = { x = 128, y = 180 },  -- bouton FUITE sur l'écran tactile
  detection_shiny = true,
  slot_savestate  = 9,     -- emplacement de la sauvegarde d'état sur un shiny
  pause_shiny     = true,  -- pause de l'émulateur sur un shiny
  delai_pause     = 2,     -- images entre l'apparition des étoiles et la pause
  etoiles_seuil   = 45,    -- points d'étoiles en plus pour dire "les étoiles sont là"
  debut_scene     = 40,    -- images ignorées au début du combat (transition)
  etoiles_max     = 420,   -- pause de secours (images après la détection du shiny)
  test_shiny      = false, -- true = chaque Pokémon traité comme un shiny (test)
  touche_on_off   = "K",
}

-- ---------------------------------------------------------------------
-- Lecture mémoire
local function oct(a)
  local ok, v = pcall(memory.readbyte, a)
  return (ok and type(v) == "number") and v % 256 or 0
end
local function mot(a) return oct(a) + oct(a + 1) * 256 end

-- Jeux reconnus : code du jeu dans l'en-tête de la ROM -> adresses
-- (décalage selon la langue : F = français)
local JEUX = {
  IRB = { nom = "Noire",     gen = "bw",   decal = { E = 0,    F = -0x80, I = -0x100, D = -0xC0, S = -0x40, J = -0x1A0 } },
  IRA = { nom = "Blanche",   gen = "bw",   decal = { E = 0x20, F = -0x60, I = -0xE0,  D = -0xA0, S = -0x40, J = -0x180 } },
  IRE = { nom = "Noire 2",   gen = "b2w2", decal = { E = 0,    F = 0x20,  I = -0x100, D = -0xC0, S = -0x40, J = -0x660 } },
  IRD = { nom = "Blanche 2", gen = "b2w2", decal = { E = 0x40, F = 0x40,  I = -0xE0,  D = -0xA0, S = -0x20, J = -0x640 } },
}
local ADR = {
  bw   = { combat = 0x0226ACE6, nb_ennemis = 0x0226ACF0, ennemi = 0x0226ACF4,
           touche = 0x020A8362, rien = 0x021509DB, texte = 0x02172BA0 },
  b2w2 = { combat = 0x02258D86, nb_ennemis = 0x02258D90, ennemi = 0x02258D94,
           touche = 0x0209B3CA, rien = 0x0214BC62, texte = 0x0216E640 },
}

local A = nil  -- adresses du jeu en cours (nil = jeu non reconnu)
local nom_jeu = ""
local function detecter_jeu()
  local code = string.char(oct(0x023FFE0C), oct(0x023FFE0D), oct(0x023FFE0E))
  local langue = string.char(oct(0x023FFE0F))
  local j = JEUX[code]
  if not j or not j.decal[langue] then A = nil; return end
  local d, base = j.decal[langue], ADR[j.gen]
  A = {}
  for k, v in pairs(base) do A[k] = v + d end
  nom_jeu = j.nom
end

local function en_combat()    return oct(A.combat) == 0x41 end
local function ca_mord()      return mot(A.touche) == 0xFFF1 end
local function rien_ne_mord() return oct(A.rien) ~= 0 end
-- Boîte de texte de la carte (« Rien de rien... ») : grande bande sombre en bas
-- de l'écran du haut. (La case mémoire « texte » de pokebot-nds ne change pas
-- dans Blanche 2 FR : on regarde l'image.)
local function texte_ouvert()
  local n, o = 0, CONFIG.Y_ECRAN_HAUT
  for y = 152, 184, 4 do
    for x = 16, 240, 4 do
      local r, g, b = gui.getpixel(x, y + o)
      if r and math.max(r, g, b) < 45 then n = n + 1 end
    end
  end
  return n >= 205   -- ~513 points : boîte ≈ 360, carte ≈ 10
end

-- ---------------------------------------------------------------------
-- Données du Pokémon (même chiffrement qu'en 4e génération)
local function bxor16(a, b)
  local r, p = 0, 1
  for _ = 1, 16 do
    local x, y = a % 2, b % 2
    if x ~= y then r = r + p end
    a, b, p = (a - x) / 2, (b - y) / 2, p * 2
  end
  return r
end
local function lcg(seed)
  local lo, hi = seed % 65536, math.floor(seed / 65536)
  local r = lo * 0x4E6D + 0x6073
  local haut = (hi * 0x4E6D + lo * 0x41C6 + math.floor(r / 65536)) % 65536
  return haut * 65536 + r % 65536
end
local POS_BLOC_A = { [0]=1,1,1,1,1,1, 2,2,3,4,3,4, 2,2,3,4,3,4, 2,2,3,4,3,4 }

local function analyser_pokemon(o)
  local function m(i) return o[i + 1] + o[i + 2] * 256 end
  local pid_bas, pid_haut, somme = m(0), m(2), m(6)
  local seed, total, clair = somme, 0, {}
  for i = 0, 63 do
    seed = lcg(seed)
    local v = bxor16(m(8 + i * 2), math.floor(seed / 65536))
    clair[i] = v
    total = (total + v) % 65536
  end
  if total ~= somme then return nil end
  local decal = math.floor(((pid_haut % 4) * 65536 + pid_bas) / 8192) % 32 % 24
  local base = (POS_BLOC_A[decal] - 1) * 16
  local espece, tid, sid = clair[base], clair[base + 2], clair[base + 3]
  if espece < 1 or espece > 649 then return nil end
  local v = bxor16(bxor16(tid, sid), bxor16(pid_haut, pid_bas))
  return { pid = pid_haut * 65536 + pid_bas, espece = espece, shiny = v < 8 }
end

local function lire_ennemi()
  local nb = oct(A.nb_ennemis)
  if nb == 0 or nb > 2 then return nil end
  local o = {}
  for i = 0, 0x87 do o[i + 1] = oct(A.ennemi + i) end
  return analyser_pokemon(o)
end

-- ---------------------------------------------------------------------
-- Étoiles du shiny (5e génération) : d'abord des boules blanches, puis des
-- étoiles cyan. Le bot compte les points cyan (vert ≈ bleu, peu de rouge) autour
-- de l'adversaire ; le ciel et les plateformes, plus bleus, ne comptent pas.
-- Sur tes captures : boules blanches ≈ 23 points, étoiles cyan ≈ 72, combat normal 0.
local function compter_etoiles()
  local n, o = 0, CONFIG.Y_ECRAN_HAUT
  for y = 0, 138 do
    for x = 126, 254 do
      local r, g, b = gui.getpixel(x, y + o)
      if not (x >= 170 and x <= 220 and y >= 30 and y <= 95)
         and r and r <= 130 and g >= 200 and b >= 195 and math.abs(g - b) <= 25 then n = n + 1 end
    end
  end
  return n
end

-- ---------------------------------------------------------------------
-- Touches
local function lire_joypad()
  local ok, j = pcall(joypad.peek)
  if not ok or type(j) ~= "table" then ok, j = pcall(joypad.get, 1) end
  if not ok or type(j) ~= "table" then ok, j = pcall(joypad.get) end
  if not ok or type(j) ~= "table" then return {} end
  return j
end
local touche_a_tenir, frames_touche = nil, 0
local function demander_appui(t) touche_a_tenir, frames_touche = t, CONFIG.frames_appui end
local touche_ecran = 0

-- ---------------------------------------------------------------------
local actif, etat = true, "attente"
local compteur, essais, nb_lancers, nb_touches, nb_combats = 0, 0, 0, 0, 0
local hors_combat, frames_combat, ennemi_lu, shiny_fait = 0, 0, false, false
local pid_combat, pid_precedent, pid_sauve = nil, nil, nil
local save_ok, pause_dans = false, -1
local attente_etoiles, frames_shiny, base_etoiles, vu_etoiles = false, 0, 99999, 0
local Y_avant, K_avant = false, false
local attente_vue = false   -- vrai une fois que la canne est lancée et attend (pas encore de touche)
local etat_charge, derniere_frame = 0, nil

local MESSAGES = {
  attente = "Bot : Y pour pecher", lancer = "Bot : peche", peche = "Bot : peche",
  ferre = "Bot : ca mord !", fermer_texte = "Bot : peche", relancer = "Bot : peche",
  combat = "Bot : Y = fuir", fuite = "Bot : fuite...",
}
local Y_BAS = CONFIG.Y_ECRAN_HAUT + 192
local function afficher()
  local msg
  if not A then msg = "Bot BW : jeu non reconnu"
  elseif not actif then msg = "Bot : OFF (K)"
  elseif etat == "shiny" then msg = "SHINY !!! " .. (save_ok and ("etat sauve (" .. CONFIG.slot_savestate .. ")") or "")
  elseif etat == "combat" and ennemi_lu then msg = "Bot : pas shiny, Y = fuir"
  else
    msg = MESSAGES[etat] or "Bot"
    if etat == "peche" and nb_lancers > 0 then msg = msg .. " #" .. nb_lancers end
  end
  gui.text(254 - #msg * 6, 2 + Y_BAS, msg)
end

local function lancer_canne()
  attente_vue = false
  demander_appui("Y")
  nb_lancers = nb_lancers + 1
  etat, compteur = "peche", CONFIG.delai_max
end

local function vers_combat()
  etat, hors_combat, frames_combat, ennemi_lu, shiny_fait = "combat", 0, 0, false, false
  nb_combats = nb_combats + 1
end

-- Après le chargement d'une sauvegarde d'état : le bot se recale
local function recaler()
  touche_a_tenir, touche_ecran, pause_dans, attente_etoiles = nil, 0, -1, false
  pcall(stylus.set, { touch = false })
  pid_precedent, pid_combat = nil, nil
  if not actif or not A then return end
  if etat == "attente" and nb_lancers == 0 then return end   -- pas encore de première pêche
  if en_combat() then vers_combat()
  elseif texte_ouvert() then etat, compteur, essais = "fermer_texte", 0, 0
  elseif nb_lancers > 0 or etat ~= "attente" then etat, compteur, attente_vue = "peche", CONFIG.delai_max, true
  end
end
pcall(savestate.registerload, function() etat_charge = 2 end)

-- ---------------------------------------------------------------------
local frame = 0
while true do
  frame = frame + 1
  if frame % 60 == 1 or not A then detecter_jeu() end

  local okf, fc = pcall(emu.framecount)
  if okf and type(fc) == "number" then
    if derniere_frame and fc ~= derniere_frame + 1 and fc ~= derniere_frame and etat_charge == 0 then etat_charge = 2 end
    derniere_frame = fc
  end
  if etat_charge > 0 then
    etat_charge = etat_charge - 1
    if etat_charge == 0 then recaler() end
  end

  -- touche K : pause / reprise du bot
  local okk, k = pcall(input.get)
  local K = okk and type(k) == "table" and k[CONFIG.touche_on_off] and true or false
  if K and not K_avant then actif = not actif; etat = "attente" end
  K_avant = K

  local j = lire_joypad()
  local Y = (j.Y or j.y) and true or false
  local Y_joueur = Y and not Y_avant and touche_a_tenir ~= "Y"
  Y_avant = Y

  if actif and A then
    local combat = en_combat()

    -- Le joueur lance la canne lui-même : la boucle démarre
    if Y_joueur and not combat and etat ~= "combat" and etat ~= "fuite" and etat ~= "shiny" then
      nb_lancers = nb_lancers + 1
      etat, compteur, attente_vue = "peche", CONFIG.delai_max, false
    end

    -- Un combat commence pendant la pêche (en attente du premier Y, le bot ne fait
    -- rien : au démarrage du jeu, la mémoire peut ressembler à un combat)
    if combat and etat ~= "combat" and etat ~= "fuite" and etat ~= "shiny" and etat ~= "attente" then vers_combat() end

    if etat == "peche" then
      compteur = compteur - 1
      if not ca_mord() then attente_vue = true end      -- la touche du lancer précédent est effacée
      if compteur < CONFIG.delai_max - 30 then          -- laisse le temps au lancer
        if ca_mord() and attente_vue then
          demander_appui("A")                            -- on ferre !
          nb_touches = nb_touches + 1
          etat, compteur = "ferre", 400
        elseif texte_ouvert() or rien_ne_mord() or compteur <= 0 then
          etat, compteur, essais = "fermer_texte", 20, 0
        end
      end

    elseif etat == "ferre" then
      -- "Un Pokémon a mordu !" -> A jusqu'au combat
      compteur = compteur - 1
      if compteur % 30 == 0 and texte_ouvert() then demander_appui("A") end
      if compteur <= 0 then etat, compteur, essais = "fermer_texte", 0, 0 end

    elseif etat == "fermer_texte" then
      -- A seulement quand une boîte de texte est ouverte (sinon A parlerait à l'eau)
      if compteur > 0 then
        compteur = compteur - 1
      elseif texte_ouvert() and essais < 30 then
        demander_appui((essais % 3 == 2) and "B" or "A")
        essais, compteur = essais + 1, 40
      elseif not texte_ouvert() then
        etat, compteur = "relancer", 40
      else
        etat = "attente"
      end

    elseif etat == "relancer" then
      if texte_ouvert() then etat, compteur, essais = "fermer_texte", 0, 0
      else
        compteur = compteur - 1
        if compteur <= 0 then lancer_canne() end
      end

    elseif etat == "combat" or etat == "fuite" then
      frames_combat = frames_combat + 1
      -- lecture de l'adversaire (shiny ?)
      if combat and CONFIG.detection_shiny and not shiny_fait and frames_combat % 5 == 0 then
        local r = lire_ennemi()
        if r and r.pid == pid_precedent and frames_combat < 240 then r = nil end   -- données du combat précédent
        if r then
          ennemi_lu, pid_combat = true, r.pid
          if r.shiny or CONFIG.test_shiny then
            shiny_fait = true
            etat, touche_a_tenir, touche_ecran = "shiny", nil, 0
            pcall(stylus.set, { touch = false })
            if r.pid ~= pid_sauve then
              save_ok = pcall(function() savestate.save(savestate.create(CONFIG.slot_savestate)) end)
              if save_ok then pid_sauve = r.pid end
            end
            attente_etoiles, frames_shiny, base_etoiles, vu_etoiles = CONFIG.pause_shiny, 0, 99999, 0
          end
        end
      end
      if etat == "combat" and Y_joueur and combat then
        etat, compteur, essais = "fuite", 20, 0
      end
      if etat == "fuite" then
        essais = essais + 1
        if not combat or essais > 900 then etat = "combat"
        elseif compteur > 0 then compteur = compteur - 1
        elseif touche_ecran == 0 then touche_ecran, compteur = 4, 12 end
      end
      -- fin du combat -> relance
      if etat == "combat" or etat == "fuite" then
        if not combat and not texte_ouvert() then hors_combat = hors_combat + 1 else hors_combat = 0 end
        if hors_combat >= CONFIG.fin_combat then
          if pid_combat then pid_precedent, pid_combat = pid_combat, nil end
          lancer_canne()
        end
      end

    elseif etat == "shiny" then
      if attente_etoiles then
        frames_shiny = frames_shiny + 1
        if frames_shiny >= CONFIG.debut_scene then
          local e = compter_etoiles()
          if e < base_etoiles then base_etoiles = e end
          if e >= base_etoiles + CONFIG.etoiles_seuil then vu_etoiles = vu_etoiles + 1 else vu_etoiles = 0 end
          if vu_etoiles >= 2 then attente_etoiles, pause_dans = false, CONFIG.delai_pause end
        end
        if attente_etoiles and frames_shiny >= CONFIG.etoiles_max then attente_etoiles, pause_dans = false, 0 end
      end
      -- retour sur la carte : le bot attend ton Y
      if not combat and not texte_ouvert() then hors_combat = hors_combat + 1 else hors_combat = 0 end
      if hors_combat >= CONFIG.fin_combat then
        if pid_combat then pid_precedent, pid_combat = pid_combat, nil end
        etat, hors_combat = "attente", 0
      end
    end
  end

  -- touches en cours
  if touche_a_tenir then
    if not pcall(joypad.set, { [touche_a_tenir] = true }) then pcall(joypad.set, 1, { [touche_a_tenir] = true }) end
    frames_touche = frames_touche - 1
    if frames_touche <= 0 then touche_a_tenir = nil end
  end
  if touche_ecran > 0 then
    pcall(stylus.set, { x = CONFIG.bouton_fuite.x, y = CONFIG.bouton_fuite.y, touch = true })
    touche_ecran = touche_ecran - 1
    if touche_ecran == 0 then pcall(stylus.set, { touch = false }) end
  end

  afficher()
  if pause_dans >= 0 then
    if pause_dans == 0 then pcall(emu.pause) end
    pause_dans = pause_dans - 1
  end
  emu.frameadvance()
end
