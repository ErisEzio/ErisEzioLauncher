-- ============================================================================
--  TEST : rend shiny chaque Pokémon sauvage rencontré
--  (Rubis / Saphir / Émeraude / Rouge Feu / Vert Feuille, mGBA 0.10+)
--
--  À charger EN PLUS du bot de pêche, dans la même fenêtre Scripting
--  (File > Load script...). À retirer après le test : File > Reset.
--  Ne sauvegarde pas une partie avec un Pokémon obtenu grâce à ce script
--  si tu veux garder une partie « propre ».
-- ============================================================================

local EQUIPE = {
  BPE = { 0x2024744 },                      -- Émeraude
  BPR = { 0x202402c }, BPG = { 0x202402c }, -- Rouge Feu / Vert Feuille
  AXV = { 0x30045d0, 0x30045c0 },           -- Rubis
  AXP = { 0x30045d0, 0x30045c0 },           -- Saphir
}

local adresses, dernier = nil, {}

local function u32(a) return emu:read32(a) end

-- Rend shiny le Pokémon à l'adresse a, en gardant ses données (ré-chiffrement)
local function rendre_shiny(a)
  local pid, otid = u32(a), u32(a + 4)
  if pid == 0 and otid == 0 then return nil end
  -- somme de contrôle valide ?
  local cle, somme = pid ~ otid, 0
  local donnees = {}
  for i = 0, 11 do
    local w = u32(a + 0x20 + i * 4) ~ cle
    donnees[i] = w
    somme = somme + (w & 0xFFFF) + (w >> 16)
  end
  if (somme & 0xFFFF) ~= emu:read16(a + 0x1C) then return nil end
  local sv = (otid & 0xFFFF) ~ (otid >> 16) ~ (pid & 0xFFFF) ~ (pid >> 16)
  if sv < 8 then return pid end                -- déjà shiny
  -- nouveau PID shiny, même ordre des sous-structures (PID % 24) et même nature (PID % 25)
  local npid
  for bas = 0, 0xFFFF do
    local haut = (otid >> 16) ~ (otid & 0xFFFF) ~ bas
    local c = (haut << 16) | bas
    if c % 24 == pid % 24 and c % 25 == pid % 25 then npid = c; break end
  end
  if not npid then return nil end
  local ncle = npid ~ otid
  for i = 0, 11 do emu:write32(a + 0x20 + i * 4, donnees[i] ~ ncle) end
  emu:write32(a, npid)
  console:log(("TEST shiny : PID %08X -> %08X"):format(pid, npid))
  return npid
end

local function sur_image()
  if not adresses then
    local ok, code = pcall(function() return emu:readRange(0x080000AC, 4) end)
    if not ok then return end
    adresses = EQUIPE[code:sub(1, 3)]
    if not adresses then return end
    console:log("TEST shiny actif : chaque Pokémon sauvage rencontré sera shiny.")
  end
  for _, a in ipairs(adresses) do
    local pid = u32(a)
    if pid ~= dernier[a] then
      -- tant que les données ne sont pas complètes (somme de contrôle), on réessaie
      dernier[a] = rendre_shiny(a)
    end
  end
end

callbacks:add("frame", sur_image)
