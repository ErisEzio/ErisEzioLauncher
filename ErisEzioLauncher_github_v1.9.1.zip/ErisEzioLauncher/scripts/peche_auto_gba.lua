-- ============================================================================
--  Bot de pêche automatique — Pokémon Rubis / Saphir / Émeraude /
--  Rouge Feu / Vert Feuille, pour mGBA 0.10 ou plus récent.
--
--  Chargement : mGBA > Outils > Scripting... > Fichier > Charger un script.
--
--  Fonctionnement (comme sur DS) :
--   * Enregistre la canne sur Select, puis lance la première pêche toi-même
--     avec Select. Le bot prend ensuite le relais : il ferre au « ! »,
--     ferme les messages d'échec et relance la canne.
--   * En combat, il attend. Appuie sur Select : le bot choisit FUITE,
--     puis relance la canne après le combat.
--   * Shiny : sauvegarde d'état dans l'emplacement 9 dès la détection,
--     puis l'image est figée au moment exact des étoiles (le son est coupé).
--     Select ne fait plus fuir. Appuie sur Start pour reprendre la main
--     (le bot s'arrête).
--   * L + R (ou K sur mGBA 0.11) : bot ON / OFF.
--  Les messages du bot s'affichent dans la fenêtre Scripting (onglet
--  « Bot de pêche »).
-- ============================================================================

local CONFIG = {
  slot_save          = 9,    -- emplacement de la sauvegarde d'état du shiny
  delai_etoiles      = 0,    -- images à attendre après l'apparition des étoiles
  delai_max_etoiles  = 900,  -- secours : figer au plus tard 15 s après le début du combat
  attente_relance    = 25,   -- images avant de relancer la canne après un échec
  attente_apres_combat = 90, -- images avant de relancer la canne après un combat
  intervalle_relance = 50,   -- images entre deux essais de relance
  essais_relance     = 8,    -- au-delà, le bot attend que tu relances toi-même
}

-- Touches GBA (numéros de bit)
local A, B, SELECT, START, RIGHT, LEFT, UP, DOWN, R, L = 0, 1, 2, 3, 4, 5, 6, 7, 8, 9
local function bitk(k) return 1 << k end

-- Adresses (tables des symboles de pokebot-gen3 : toutes langues, toutes révisions)
local FRLG = {
  peche   = { 0x805d304, 0x805d318, 0x805d3c4, 0x805d2f0, 0x805cbc0, 0x805d3d8 },
  main    = { 0x3003040, 0x30030f0, 0x3003130 },
  combat  = 0x439,
  equipe  = { 0x202402c, 0x2023f8c },
  sprites = { 0x202063c, 0x20205bc },
}
local JEUX = {
  BPE = { nom = "Émeraude",
          peche   = { 0x808c8d0, 0x808c8c0, 0x808c8dc, 0x808c8d4, 0x808c224 },
          main    = { 0x30022c0, 0x3002360 },
          combat  = 0x439,
          equipe  = { 0x2024744, 0x20243e8 },
          sprites = { 0x2020630, 0x20205ac } },
  BPR = { nom = "Rouge Feu",    peche = FRLG.peche, main = FRLG.main, combat = FRLG.combat,
          equipe = FRLG.equipe, sprites = FRLG.sprites },
  BPG = { nom = "Vert Feuille", peche = FRLG.peche, main = FRLG.main, combat = FRLG.combat,
          equipe = FRLG.equipe, sprites = FRLG.sprites },
  AXV = { nom = "Rubis",
          peche   = { 0x805a7a8, 0x805a37c, 0x805a39c, 0x805a6d0, 0x805a7b8, 0x80575c8 },
          main    = { 0x3001770, 0x3001780, 0x30016e0 },
          combat  = 0x43D,
          equipe  = { 0x30045d0, 0x30045c0, 0x30044f0 },
          sprites = { 0x2020004 } },
  AXP = { nom = "Saphir",
          peche   = { 0x805a7ac, 0x805a380, 0x805a3a0, 0x805a6d4, 0x805a7bc, 0x80575cc },
          main    = { 0x3001770, 0x3001780, 0x30016e0 },
          combat  = 0x43D,
          equipe  = { 0x30045d0, 0x30045c0, 0x30044f0 },
          sprites = { 0x2020004 } },
}

local TAG_ETOILES = 10233          -- ANIM_TAG_GOLD_STARS (identique dans les 5 jeux)
local SOUNDCNT_X  = 0x04000084

-- ---------------------------------------------------------------------------
-- État
-- ---------------------------------------------------------------------------
local jeu, motifs = nil, {}
local tache = nil                  -- adresse de la tâche Task_Fishing en cours
local main_adr, main_cands = nil, {}
local sprites_adr = nil
local bot_on = true
local etat = "attente"
local t = 0                        -- compteur d'images dans l'état courant
local essais = 0
local file = {}                    -- appuis à faire : { masque, images }
local touches_bot, applique = 0, 0
local touches_user, prec_user = 0, 0
local lu_cette_image = false
local etat_gele = nil
local spam_b = 0
local pid_combat, shiny_vu = nil, false
local tampon, dernier_msg = nil, nil
local essai_demarrage = 0
local diag_n = 0
local diag_image, diag_touches = 0, 0
local relance_apres_combat = false
local derniere_etape = -1
local prochain_choix_sprites = 0

-- Journal à côté du script (bot_peche_gba.log) : utile si la fenêtre Scripting est cachée
local chemin_journal = nil
do
  local ok, src = pcall(function() return debug.getinfo(1, "S").source end)
  if ok and type(src) == "string" and src:sub(1, 1) == "@" then
    chemin_journal = src:sub(2):gsub("%.lua$", "") .. ".log"
  end
end
local function journal(msg)
  if not chemin_journal then return end
  pcall(function()
    local f = io.open(chemin_journal, "a")
    if f then f:write(os.date("%H:%M:%S "), msg, "\n"); f:close() end
  end)
end

local function afficher(msg)
  if msg == dernier_msg then return end
  dernier_msg = msg
  journal(msg:gsub("\n", " | "))
  if not (tampon and pcall(function() tampon:clear(); tampon:print(msg .. "\n") end)) then
    pcall(function() console:log(msg) end)
  end
end

local function appuyer(k, duree)
  file[#file + 1] = { bitk(k), duree or 2 }
  file[#file + 1] = { 0, 4 }
end

local function vider_file()
  file = {}
  touches_bot = 0
end

local function rom(p) return p >= 0x08000000 and p < 0x0A000000 end

-- ---------------------------------------------------------------------------
-- Lecture de la mémoire
-- ---------------------------------------------------------------------------
local function trouver_tache()
  if tache then
    local f = emu:read32(tache)
    if motifs[f] and emu:read8(tache + 4) == 1 then return tache end
    tache = nil
  end
  local s = emu:readRange(0x03000000, 0x8000)
  for _, m in ipairs(motifs) do
    local pos = 1
    while true do
      local i = s:find(m, pos, true)
      if not i then break end
      if (i - 1) % 4 == 0 and s:byte(i + 4) == 1 then
        tache = 0x03000000 + i - 1
        return tache
      end
      pos = i + 1
    end
  end
  return nil
end

local function etape_peche()
  local v = emu:read16(tache + 8)
  if v >= 0x8000 then v = v - 0x10000 end
  return v
end

-- gMain : on garde l'adresse dont le compteur de VBlank avance d'un par image
local function valider_main()
  if main_adr then return end
  for _, c in ipairs(main_cands) do
    local v = emu:read32(c.adr + 0x24)
    if v == (c.dernier + 1) & 0xFFFFFFFF and rom(emu:read32(c.adr + 4)) then
      c.score = c.score + 1
    else
      c.score = 0
    end
    c.dernier = v
    if c.score >= 10 then main_adr = c.adr; return end
  end
end

local function en_combat()
  if not main_adr then return false end
  return (emu:read8(main_adr + jeu.combat) & 2) ~= 0
end

-- Premier Pokémon adverse : PID, OTID et somme de contrôle vérifiés
local function lire_adversaire()
  for _, adr in ipairs(jeu.equipe) do
    local s = emu:readRange(adr, 0x50)
    local pid, otid = string.unpack("<I4I4", s, 1)
    if pid ~= 0 or otid ~= 0 then
      local chk = string.unpack("<I2", s, 0x1D)
      local cle, somme = pid ~ otid, 0
      for i = 0, 11 do
        local w = string.unpack("<I4", s, 0x21 + i * 4) ~ cle
        somme = somme + (w & 0xFFFF) + (w >> 16)
      end
      if (somme & 0xFFFF) == chk then
        local sv = (otid & 0xFFFF) ~ (otid >> 16) ~ (pid & 0xFFFF) ~ (pid >> 16)
        return pid, sv < 8
      end
    end
  end
  return nil
end

-- gSprites : on garde la base qui donne le plus de sprites cohérents
local function choisir_sprites()
  local meilleur, score_max = nil, -1
  for _, b in ipairs(jeu.sprites) do
    for n = 0, 32 do
      local d = (n % 2 == 0) and (n // 2) * 4 or -((n + 1) // 2) * 4
      local base, score = b + d, 0
      local s = emu:readRange(base, 64 * 0x44)
      for i = 0, 63 do
        local o = i * 0x44
        local fl = string.unpack("<I2", s, o + 0x3F)
        if fl & 1 == 1 then
          local tpl = string.unpack("<I4", s, o + 0x15)
          local cb  = string.unpack("<I4", s, o + 0x1D)
          if rom(tpl) and rom(cb) then score = score + 1 else score = score - 1 end
        end
      end
      if score > score_max then meilleur, score_max = base, score end
    end
  end
  return meilleur
end

local function etoiles_visibles()
  if not sprites_adr then return false end
  local s = emu:readRange(sprites_adr, 64 * 0x44)
  for i = 0, 63 do
    local o = i * 0x44
    local fl = string.unpack("<I2", s, o + 0x3F)
    if fl & 1 == 1 then
      local tpl = string.unpack("<I4", s, o + 0x15)
      if rom(tpl) and emu:read16(tpl) == TAG_ETOILES then return true end
    end
  end
  return false
end

-- ---------------------------------------------------------------------------
-- Gel de l'image au moment des étoiles
-- ---------------------------------------------------------------------------
local function geler()
  etat_gele = emu:saveStateBuffer()
  etat = "gel"
  vider_file()
  afficher("✨ SHINY ! ✨  Image figée (sauvegarde d'état " .. CONFIG.slot_save ..
           ").\nStart = reprendre la main (le bot s'arrête).")
end

local function degeler()
  emu:loadStateBuffer(etat_gele)   -- remet aussi le son
  etat_gele = nil
  bot_on = false
  etat = "off"
  afficher("Shiny : à toi de jouer ! Bot OFF.\nL + R pour le relancer.")
end

-- ---------------------------------------------------------------------------
-- Boucle principale
-- ---------------------------------------------------------------------------
local function changer(e) etat = e; t = 0 end

local function bot_bascule()
  bot_on = not bot_on
  vider_file()
  if bot_on then
    changer("attente")
  else
    changer("off")
    afficher("Bot : OFF (L + R pour le relancer)")
  end
end

local touche_k_avant = false
local function touche_k()
  if not input or not input.isKeyActive then return false end
  local ok, v = pcall(input.isKeyActive, input, "k")
  return ok and v
end

local demarrer
local function sur_image()
  diag_image = diag_image + 1
  if not jeu then
    -- ROM pas encore prête au chargement du script : on réessaie
    essai_demarrage = essai_demarrage + 1
    if essai_demarrage % 60 == 0 and essai_demarrage <= 600 then demarrer() end
    return
  end
  if not lu_cette_image then touches_user = emu:getKeys() & ~applique end
  lu_cette_image = false
  local appui = touches_user & ~prec_user
  prec_user = touches_user
  t = t + 1

  -- Image figée : on recharge l'état à chaque image, son coupé
  if etat == "gel" then
    if appui & bitk(START) ~= 0 then
      degeler()
    else
      emu:loadStateBuffer(etat_gele)
      emu:write16(SOUNDCNT_X, 0)
    end
    return
  end

  valider_main()

  -- Bascule ON / OFF : L + R, ou K (mGBA 0.11)
  local lr = bitk(L) | bitk(R)
  local k = touche_k()
  if (touches_user & lr == lr and appui & lr ~= 0) or (k and not touche_k_avant) then
    bot_bascule()
  end
  touche_k_avant = k
  if not bot_on then return end

  local tch = trouver_tache()
  local combat = en_combat()

  if etat == "attente" then
    afficher("Bot : ON — lance la première pêche avec Select\n(L + R : bot OFF)")
    if tch then changer("peche") end

  elseif etat == "peche" then
    afficher("Bot : pêche en cours…")
    if combat then
      changer("combat")
    elseif tch then
      local e = etape_peche()
      derniere_etape = e
      if e == 7 then                         -- « ! » : on ferre
        if #file == 0 then appuyer(A, 2) end
      elseif e == 9 or e == 10 then          -- « Un Pokémon a mordu ! » : A lance le combat
        if #file == 0 and t % 8 == 0 then appuyer(A, 2) end
      elseif e >= 11 and e <= 15 then        -- échec : on ferme le message
        if #file == 0 and t % 8 == 0 then appuyer(B, 2) end
      end
    else
      essais = 0
      if derniere_etape == 9 or derniere_etape == 10 then
        changer("transition")              -- un Pokémon est ferré : le combat arrive
      else
        changer("relancer")
      end
      derniere_etape = -1
    end

  elseif etat == "transition" then
    if combat then
      changer("combat")
    elseif tch then
      changer("peche")
    elseif t > 600 then
      changer("relancer")
    end

  elseif etat == "relancer" then
    afficher("Bot : relance de la canne…")
    if combat then
      changer("combat")
    elseif tch then
      changer("peche")
    else
      local attente = CONFIG.attente_relance
      if relance_apres_combat then attente = CONFIG.attente_apres_combat end
      if t >= attente and (t - attente) % CONFIG.intervalle_relance == 0 and #file == 0 then
        essais = essais + 1
        if essais > CONFIG.essais_relance then
          relance_apres_combat = false
          changer("attente")
        else
          appuyer(SELECT, 2)
        end
      end
    end

  elseif etat == "combat" then
    if t == 1 then
      vider_file()
      pid_combat, shiny_vu = nil, false
      spam_b = 0
    end
    if not pid_combat and t <= 60 then
      local pid, shiny = lire_adversaire()
      if pid then
        pid_combat = pid
        if shiny then
          emu:saveStateSlot(CONFIG.slot_save)
          prochain_choix_sprites = 0
          changer("shiny")
          afficher("✨ SHINY détecté ! Sauvegarde d'état " .. CONFIG.slot_save ..
                   " faite.\nPause aux étoiles…")
          return
        end
      end
    end
    if combat then
      afficher("Bot : combat — Select = fuir")
      if appui & bitk(SELECT) ~= 0 then
        spam_b = 900                         -- on insiste jusqu'à 15 s
      end
      if spam_b > 0 then
        -- B (ferme un texte ou le menu des attaques), puis FUITE en bas à droite : Droite, Bas, A.
        -- Répété tant que le combat dure : passe les textes et réessaie si la fuite échoue.
        spam_b = spam_b - 1
        if #file == 0 then
          appuyer(B, 2); appuyer(RIGHT, 2); appuyer(DOWN, 2); appuyer(A, 2)
          file[#file + 1] = { 0, 14 }
        end
      end
    else
      relance_apres_combat = true
      essais = 0
      vider_file()
      changer("relancer")
    end

  elseif etat == "shiny" then
    -- Select ne fait plus rien : on attend les étoiles
    if t >= prochain_choix_sprites then
      sprites_adr = choisir_sprites()
      prochain_choix_sprites = t + 30
    end
    if etoiles_visibles() then
      if not shiny_vu then shiny_vu = t end
    end
    if (shiny_vu and t - shiny_vu >= CONFIG.delai_etoiles) or t >= CONFIG.delai_max_etoiles then
      geler()
    end
  end

  if etat == "peche" or etat == "attente" then relance_apres_combat = false end

  -- Touche à envoyer pendant l'image suivante
  if #file > 0 then
    touches_bot = file[1][1]
    file[1][2] = file[1][2] - 1
    if file[1][2] <= 0 then table.remove(file, 1) end
  else
    touches_bot = 0
  end
end

local function sur_lecture_touches()
  diag_touches = diag_touches + 1
  if not jeu then return end
  local kk = emu:getKeys()
  if not lu_cette_image then
    touches_user = kk & ~applique
    lu_cette_image = true
  end
  emu:setKeys((kk & ~applique) | touches_bot)
  applique = touches_bot
end

-- ---------------------------------------------------------------------------
-- Démarrage
-- ---------------------------------------------------------------------------
demarrer = function()
  jeu = nil
  diag_n = diag_n + 1
  if not emu then
    if diag_n <= 3 then journal("diag : emu absent") end
    return
  end
  local ok, code = pcall(function() return emu:readRange(0x080000AC, 4) end)
  if not ok or type(code) ~= "string" then
    if diag_n <= 3 then journal("diag : lecture ROM impossible : " .. tostring(code) .. " (" .. type(code) .. ")") end
    -- autre façon de lire l'en-tête
    local ok2, a, b2, c2, d2 = pcall(function()
      return emu:read8(0x080000AC), emu:read8(0x080000AD), emu:read8(0x080000AE), emu:read8(0x080000AF)
    end)
    if not ok2 then return end
    code = string.char(a, b2, c2, d2)
  end
  code = code:gsub("[^%w]", "?")
  jeu = JEUX[code:sub(1, 3)]
  if not tampon then
    local ok, b = pcall(console.createBuffer, console, "Bot de pêche")
    if ok then tampon = b end
  end
  if not jeu then
    afficher("Bot de pêche : jeu non reconnu (" .. code .. ").\n" ..
             "Jeux pris en charge : Rubis, Saphir, Émeraude, Rouge Feu, Vert Feuille.")
    return
  end
  motifs = {}
  for _, a in ipairs(jeu.peche) do
    local p = string.pack("<I4", a | 1)
    motifs[#motifs + 1] = p
    motifs[a | 1] = true
  end
  main_cands, main_adr = {}, nil
  for _, a in ipairs(jeu.main) do
    for d = -0x20, 0x20, 0x10 do
      main_cands[#main_cands + 1] = { adr = a + d, dernier = -1, score = 0 }
    end
  end
  tache, sprites_adr, etat_gele = nil, nil, nil
  bot_on = true
  vider_file()
  changer("attente")
  dernier_msg = nil
  afficher("Bot de pêche chargé : Pokémon " .. jeu.nom .. " (" .. code .. ")")
end

-- Toute erreur est écrite dans le journal et la console, sans arrêter le bot
local erreurs = 0
local function protege(f)
  return function(...)
    local ok, err = xpcall(f, debug.traceback, ...)
    if not ok then
      erreurs = erreurs + 1
      if erreurs <= 5 then
        journal("ERREUR : " .. tostring(err))
        pcall(function() console:error(tostring(err)) end)
      end
    end
  end
end

callbacks:add("start", protege(demarrer))
callbacks:add("reset", protege(demarrer))
callbacks:add("frame", protege(sur_image))
callbacks:add("keysRead", protege(sur_lecture_touches))
journal("Script chargé")
protege(demarrer)()
