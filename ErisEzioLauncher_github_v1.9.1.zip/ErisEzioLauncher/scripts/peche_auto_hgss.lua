-- =====================================================================
--  PECHE AUTO - Pokémon Or HeartGold / Argent SoulSilver (DeSmuME)  - v4
--  Boucle de pêche automatique :
--   - lance la canne (Y)
--   - appuie sur A quand le "!" apparaît
--   - si rien ne mord / le Pokémon s'enfuit / ligne remontée trop vite :
--     ferme le texte avec A et relance la canne tout seul
--   - si un COMBAT commence : le bot attend, tu vérifies le shiny.
--       Y = le bot fuit le combat pour toi (même touche que pour pêcher).
--     Dès que le combat est fini (fuite, capture, K.O.), il relance
--     la pêche tout seul.
--
--  HGSS : la canne se lance depuis l'écran tactile (bouton de la canne,
--  à droite). Le bot touche ce bouton quand tu appuies sur Y, et empêche
--  Y d'arriver au jeu (sinon il sortirait le vélo).
--  Démarrage : place-toi face à l'eau, canne enregistrée sur l'écran tactile,
--  et fais la première pêche toi-même avec Y. Ensuite il se débrouille.
--  Un petit message en haut à droite de l'écran du bas indique l'état.
--
--  SHINY : en combat, le bot lit le Pokémon adverse dans la mémoire du jeu.
--  S'il est shiny : sauvegarde d'état automatique + pause de l'émulateur,
--  et le bot ne touche plus à rien (Y ne fait plus fuir).
--  Touche K (clavier) : activer / désactiver le script.
--
--  Repère "combat" : lu dans la mémoire du jeu (pas de Pokétch dans HGSS).
--  Le script ne fonctionne qu'avec HeartGold / SoulSilver ; sur un autre jeu
--  il affiche "jeu non reconnu" et ne fait rien.
-- =====================================================================

local CONFIG = {
  Y_ECRAN_HAUT    = -192,  -- décalage de l'écran du haut (ne pas toucher)
  zone            = { x1 = 110, y1 = 40, x2 = 146, y2 = 80 },  -- cadre du "!"

  blanc_min       = 215,  -- pixel "blanc" pour la bulle du "!"
  blancs_en_plus  = 20,   -- pixels blancs en plus du normal = "!"
  frames_confirm  = 2,    -- "!" vu 2 frames de suite
  frames_lancer   = 45,   -- animation du lancer ignorée
  frames_mesure   = 30,   -- mesure du blanc normal
  frames_appui    = 6,    -- durée d'un appui de touche
  delai_max       = 1800, -- abandon après 30 s sans "!"
  attente_apres_A = 300,  -- après le "!" : 5 s pour voir si un combat commence
  touche_on_off   = "K",

  pause_en_combat = false, -- true = met l'émulateur en pause quand un combat démarre
  fin_combat      = 90,    -- frames de retour au jeu (Pokétch) avant de relancer la pêche
  bouton_fuite    = { x = 125, y = 175 },  -- bouton FUITE sur l'écran tactile
  bouton_canne    = { x = 225, y = 62 },   -- bouton de la canne sur l'écran tactile (carte)
  bloquer_Y       = true,  -- Y n'arrive pas au jeu quand le bot est actif (pas de vélo)
  detection_shiny = true,  -- lit le Pokémon adverse en mémoire (Diamant/Perle/Platine)
  slot_savestate  = 9,     -- emplacement de la sauvegarde d'état faite sur un shiny
  pause_shiny     = true,  -- met l'émulateur en pause sur un shiny
  delai_pause     = 3,     -- images entre l'apparition des étoiles et la pause
  etoiles_seuil   = 15,    -- nb de points d'étoiles pour dire "les étoiles sont là"
  debut_scene     = 120,   -- si la boîte de texte du combat n'est pas repérée : début de la scène (images après la détection)
  etoiles_max     = 360,   -- (compté à partir de l'apparition de la boîte de texte)   -- pause de secours si aucune étoile vue (frames après l'arrivée en combat)
  test_shiny      = false, -- true = traite CHAQUE Pokémon comme un shiny (pour tester)
  debug           = false, -- true = affiche le cadre et les infos sur l'écran du haut
}

-- ---------------------------------------------------------------------
local Y_BAS = CONFIG.Y_ECRAN_HAUT + 192
local actif, etat = true, "attente"
local compteur, vu, nb_A, nb_lancers, nb_combats = 0, 0, 0, 0, 0
local blancs, blancs_normal = 0, 0
local touche_avant, Y_avant = false, false
local touche_a_tenir, frames_touche = nil, 0
local sans_poketch, essais_texte = 0, 0
local XA_avant, retour_jeu, etape_fuite, essais_fuite = false, 0, 0, 0
local touche_ecran, touche_pos = 0, nil
local frames_shiny = 0
local frames_combat, ennemi_lu, shiny_fait, pause_dans, save_ok = 0, false, false, -1, false
local pid_combat, pid_precedent, pid_sauve = nil, nil, nil
local etat_charge, derniere_frame = 0, nil
local frames_shiny = 0
            attente_etoiles, base_etoiles, vu_etoiles, frames_scene = false, 99999, 0, 0

-- Points clairs (étoiles) autour du Pokémon adverse, écran du haut
local N_ETOILES = 65 * 70
-- Lettres sombres dans la boîte de texte = le texte « Un ... sauvage apparaît ! » commence
local function texte_ecrit()
  local n, o = 0, CONFIG.Y_ECRAN_HAUT
  for y = 154, 184, 2 do
    for x = 20, 228, 2 do
      local r, g, b = gui.getpixel(x, y + o)
      if r and r < 140 and g < 140 and b < 140 then n = n + 1 end
    end
  end
  return n >= 6
end

local function compter_etoiles()
  local n, o = 0, CONFIG.Y_ECRAN_HAUT
  for y = 0, 138, 2 do
    for x = 126, 254, 2 do
      local r, g, b = gui.getpixel(x, y + o)
      -- étoiles : bleu très clair, presque blanc. On ignore la zone du Pokémon
      -- (son sprite peut être clair) ; les bulles d'eau, plus foncées, ne comptent pas.
      if not (x >= 170 and x <= 220 and y >= 30 and y <= 95)
         and r and r >= 170 and g >= 185 and b >= 215 then n = n + 1 end   -- de jour, l'eau et les bulles restent sous r=150
    end
  end
  return n
end

-- ===== Détection shiny par lecture mémoire (Gen 4) =====
local function bxor16(a, b)
  local r, p = 0, 1
  for _ = 1, 16 do
    local x, y = a % 2, b % 2
    if x ~= y then r = r + p end
    a, b, p = (a - x) / 2, (b - y) / 2, p * 2
  end
  return r
end

-- seed = seed * 0x41C64E6D + 0x6073 (mod 2^32), sans dépasser la précision des nombres Lua
local function lcg(seed)
  local lo, hi = seed % 65536, math.floor(seed / 65536)
  local r = lo * 0x4E6D + 0x6073
  local haut = (hi * 0x4E6D + lo * 0x41C6 + math.floor(r / 65536)) % 65536
  return haut * 65536 + r % 65536
end

local POS_BLOC_A = { [0]=1,1,1,1,1,1, 2,2,3,4,3,4, 2,2,3,4,3,4, 2,2,3,4,3,4 }

-- octets = table des 0x88 premiers octets d'un Pokémon (indices 1..136)
-- renvoie nil si les données ne sont pas valides, sinon { pid, espece, tid, sid, shiny }
local function analyser_pokemon(o)
  if #o < 0x88 then return nil end
  local function mot(i) return o[i + 1] + o[i + 2] * 256 end
  local pid_bas, pid_haut, somme = mot(0), mot(2), mot(6)
  local seed, total, clair = somme, 0, {}
  for i = 0, 63 do
    seed = lcg(seed)
    local m = bxor16(mot(8 + i * 2), math.floor(seed / 65536))
    clair[i] = m
    total = (total + m) % 65536
  end
  if total ~= somme then return nil end
  local decal = math.floor(((pid_haut % 4) * 65536 + pid_bas) / 8192) % 32 % 24
  local base = (POS_BLOC_A[decal] - 1) * 16
  local espece, tid, sid = clair[base], clair[base + 2], clair[base + 3]
  if espece < 1 or espece > 493 then return nil end
  local v = bxor16(bxor16(tid, sid), bxor16(pid_haut, pid_bas))
  return { pid = pid_haut * 65536 + pid_bas, espece = espece, tid = tid, sid = sid, valeur = v, shiny = v < 8 }
end

local function oct(a)
  local ok, v = pcall(memory.readbyte, a)
  return (ok and type(v) == "number") and v % 256 or 0
end
local function dmot(a) return oct(a) + oct(a + 1) * 256 + oct(a + 2) * 65536 + oct(a + 3) * 16777216 end
local function en_ram(p) return p >= 0x02000000 and p < 0x02400000 end

-- Adresses d'après le projet libre pokebot-nds (décalage selon la langue du jeu)
-- Adresses d'après le projet libre pokebot-nds (décalage selon la langue du jeu)
local DECAL_HG = { E = 0, F = 0x20, I = -0x60, D = -0x20, S = 0x20, J = -0x3B08 }
local DECAL_SS = { E = 0, F = 0x20, I = -0x60, D = -0x20, S = 0x40, J = -0x3B08 }

-- Base des pointeurs si le jeu est HeartGold / SoulSilver, sinon nil
local function base_hgss()
  local c1, c2, c3 = string.char(oct(0x023FFE0C)), string.char(oct(0x023FFE0D)), string.char(oct(0x023FFE0E))
  local langue = string.char(oct(0x023FFE0F))
  if c1 == "I" and c2 == "P" then
    if c3 == "K" and DECAL_HG[langue] then return 0x21D4158 + DECAL_HG[langue] end
    if c3 == "G" and DECAL_SS[langue] then return 0x21D4158 + DECAL_SS[langue] end
  end
  return nil
end

local function adresse_ennemi()
  local base = base_hgss()
  if not base then return nil end
  local ancre = dmot(base)
  if not en_ram(ancre) then return nil end
  local ancre2 = dmot(ancre + 0x6930)
  if not en_ram(ancre2) then return nil end
  return ancre2 + 0xC18
end

-- Vrai si un combat est en cours (données de l'adversaire présentes et valides)
local function combat_memoire()
  local a = adresse_ennemi()
  if not a or not en_ram(a) then return false end
  local nb = oct(a - 4)
  if nb == 0 or nb > 2 then return false end
  local o = {}
  for i = 0, 0x87 do o[i + 1] = oct(a + i) end
  return analyser_pokemon(o) ~= nil
end

-- Lit le Pokémon adverse ; nil tant que les données ne sont pas prêtes / valides
local function lire_ennemi()
  local a = adresse_ennemi()
  if not a or not en_ram(a) or oct(a - 4) == 0 then return nil end
  local o = {}
  for i = 0, 0x87 do o[i + 1] = oct(a + i) end
  return analyser_pokemon(o)
end

local function lire_joypad()
  -- peek = ce que tu appuies réellement (le jeu, lui, ne reçoit pas Y)
  local ok, j = pcall(joypad.peek)
  if not ok or type(j) ~= "table" then ok, j = pcall(joypad.get, 1) end
  if not ok or type(j) ~= "table" then ok, j = pcall(joypad.get) end
  if not ok or type(j) ~= "table" then return {} end
  return j
end

local function presser(touche)
  if not pcall(joypad.set, { [touche] = true }) then
    pcall(joypad.set, 1, { [touche] = true })
  end
end

-- appuie sur une touche pendant quelques frames (géré à chaque frame)
local function demander_appui(touche)
  touche_a_tenir, frames_touche = touche, CONFIG.frames_appui
end

local function compter_blancs()
  local n, z, o, s = 0, CONFIG.zone, CONFIG.Y_ECRAN_HAUT, CONFIG.blanc_min
  for y = z.y1, z.y2 do
    for x = z.x1, z.x2 do
      local r, g, b = gui.getpixel(x, y + o)
      if r and r >= s and g >= s and b >= s then n = n + 1 end
    end
  end
  return n
end

-- Boîte de texte blanche en bas de l'écran du haut ?
local function texte_visible()
  local n, o = 0, CONFIG.Y_ECRAN_HAUT
  for y = 152, 186, 4 do
    for x = 16, 240, 4 do
      local r, g, b = gui.getpixel(x, y + o)
      if r and r >= 230 and g >= 230 and b >= 230 then n = n + 1 end
    end
  end
  return n >= 250   -- ~510 points testés ; boîte = ~450, sans boîte = ~0
end

-- Écran vert du Pokétch visible en bas ? (= on n'est pas en combat)
-- HGSS n'a pas de Pokétch : "hors combat" = aucun combat dans la mémoire du jeu
-- (le nom est gardé pour ne pas changer la logique du bot Diamant/Perle/Platine)
local function poketch_visible()
  return not combat_memoire()
end

local function verifier_touche_clavier()
  local ok, k = pcall(input.get)
  if not ok or type(k) ~= "table" then return end
  local maintenant = k[CONFIG.touche_on_off] and true or false
  if maintenant and not touche_avant then
    actif = not actif
    etat = "attente"
  end
  touche_avant = maintenant
end

local COULEURS = {
  attente = "#00AAFFFF", lancer = "#FFFF00FF", mesure = "#CC44FFFF",
  surveillance = "#00FF00FF", apres_touche = "#FFFFFFFF",
  fermer_texte = "#FF8800FF", relancer = "#FF8800FF", combat = "#FF00FFFF",
}

local MESSAGES = {
  attente = "Bot : Y pour pecher", lancer = "Bot : peche", mesure = "Bot : peche",
  surveillance = "Bot : peche", apres_touche = "Bot : ca mord !",
  fermer_texte = "Bot : peche", relancer = "Bot : peche",
  combat = "Bot : Y = fuir", fuite = "Bot : fuite...", shiny = "SHINY !!!",
}

local jeu_ok = nil
local function afficher()
  local o = CONFIG.Y_ECRAN_HAUT
  if jeu_ok == false then
    local m = "Bot HGSS : jeu non reconnu"
    gui.text(254 - #m * 6, 2 + Y_BAS, m)
    return
  end
  if CONFIG.debug then
    local z = CONFIG.zone
    local couleur = actif and (COULEURS[etat] or "#FFFF00FF") or "#FF0000FF"
    gui.box(z.x1 - 2, z.y1 - 2 + o, z.x2 + 2, z.y2 + 2 + o, "#00000000", couleur)
    gui.text(2, 2 + o, "etat: " .. etat .. "  blancs: " .. blancs .. "/" .. (blancs_normal + CONFIG.blancs_en_plus))
    gui.text(2, 12 + o, "lancers: " .. nb_lancers .. "  touches: " .. nb_A .. "  combats: " .. nb_combats)
  end
  -- petit message en haut à droite de l'écran du bas (hors des boutons du combat)
  local msg = actif and (MESSAGES[etat] or "Bot") or "Bot : OFF (K)"
  if actif and etat == "combat" and ennemi_lu then msg = "Bot : pas shiny, Y = fuir" end
  if actif and etat == "shiny" then
    msg = "SHINY !!! " .. (save_ok and ("etat sauve (" .. CONFIG.slot_savestate .. ")") or "")
  end
  if actif and nb_lancers > 0 and (etat == "surveillance" or etat == "mesure" or etat == "lancer") then
    msg = msg .. " #" .. nb_lancers
  end
  gui.text(254 - #msg * 6, 2 + Y_BAS, msg)
end

local function lancer_canne()
  touche_ecran, touche_pos = 6, CONFIG.bouton_canne     -- HGSS : la canne se lance au tactile
  nb_lancers = nb_lancers + 1
  etat, compteur, blancs_normal, vu, sans_poketch = "lancer", CONFIG.frames_lancer, 0, 0, 0
end

-- Après le chargement d'une sauvegarde d'état : le bot se recale sur ce qu'il voit
local function recaler()
  touche_a_tenir, touche_ecran, pause_dans, attente_etoiles = nil, 0, -1, false
  pcall(stylus.set, { touch = false })
  pid_precedent, pid_combat, frames_combat, ennemi_lu, shiny_fait = nil, nil, 0, false, false
  sans_poketch, retour_jeu, vu, essais_texte = 0, 0, 0, 0
  if not actif then return end
  if not poketch_visible() then
    etat = "combat"                                   -- chargé en plein combat
  elseif texte_visible() then
    etat, compteur = "fermer_texte", 0                -- un message est affiché
  elseif nb_lancers > 0 or etat ~= "attente" then
    etat, compteur, blancs_normal = "mesure", CONFIG.frames_mesure, 0   -- en train de pêcher
  end
end

pcall(savestate.registerload, function() etat_charge = 2 end)

-- ---------------------------------------------------------------------
while true do
  -- le bot ne tourne que sur HeartGold / SoulSilver (sinon il n'appuie sur rien)
  if jeu_ok == nil or (frame_jeu or 0) % 60 == 0 then jeu_ok = base_hgss() ~= nil end
  frame_jeu = (frame_jeu or 0) + 1
  if not jeu_ok then
    afficher()
    emu.frameadvance()
  else
  -- chargement d'une sauvegarde d'état : détecté par DeSmuME ou par un saut du compteur d'images
  local okf, fc = pcall(emu.framecount)
  if okf and type(fc) == "number" then
    if derniere_frame and fc ~= derniere_frame + 1 and fc ~= derniere_frame and etat_charge == 0 then etat_charge = 2 end
    derniere_frame = fc
  end
  if etat_charge > 0 then
    etat_charge = etat_charge - 1
    if etat_charge == 0 then recaler() end            -- une image après le chargement, l'écran est à jour
  end
  verifier_touche_clavier()
  local j = lire_joypad()
  local Y_maintenant = (j.Y or j.y) and true or false
  local Y_joueur = Y_maintenant and not Y_avant and touche_a_tenir ~= "Y"
  Y_avant = Y_maintenant
  blancs = compter_blancs()
  local XA = ((j.X or j.x) and (j.B or j.b)) and true or false
  local XA_joueur = XA and not XA_avant
  XA_avant = XA

  if actif then
    -- Le joueur lance lui-même la canne : on (re)démarre la boucle
    -- Y ne démarre la pêche que si le bot attend : avec plusieurs fenêtres, un Y donné
    -- pour fuir dans une autre fenêtre ne doit pas couper une pêche en cours.
    if Y_joueur and etat == "attente" then
      touche_ecran, touche_pos = 6, CONFIG.bouton_canne     -- Y = canne (au tactile)
      nb_lancers = nb_lancers + 1
      etat, compteur, blancs_normal, vu, sans_poketch = "lancer", CONFIG.frames_lancer, 0, 0, 0
    end

    -- Détection du shiny : on relit l'adversaire toutes les 5 frames pendant le combat
    if etat == "combat" or etat == "fuite" then
      frames_combat = frames_combat + 1
      if CONFIG.detection_shiny and not shiny_fait and frames_combat % 5 == 0 then
        local r = lire_ennemi()
        -- au début du combat, la mémoire peut encore contenir l'adversaire du combat précédent
        if r and r.pid == pid_precedent and frames_combat < 240 then r = nil end
        if r then
          pid_combat = r.pid
          ennemi_lu = true
          if r.shiny or CONFIG.test_shiny then
            shiny_fait = true
            etat, retour_jeu, touche_a_tenir, touche_ecran = "shiny", 0, nil, 0
            pcall(stylus.set, { touch = false })
            -- sauvegarde d'état tout de suite (avant l'apparition), une seule fois par shiny
            if r.pid ~= pid_sauve then
              save_ok = pcall(function() savestate.save(savestate.create(CONFIG.slot_savestate)) end)
              if save_ok then pid_sauve = r.pid end
            end
            -- pause au moment des étoiles (voir l'état "shiny")
            attente_etoiles, base_etoiles, vu_etoiles, frames_scene = CONFIG.pause_shiny, 99999, 0, 0
          end
        end
      end
    elseif etat ~= "shiny" then
      if pid_combat then pid_precedent, pid_combat = pid_combat, nil end
      frames_combat, ennemi_lu, shiny_fait = 0, false, false
    end

    -- Sécurité : si le Pokétch disparaît pendant la pêche, c'est un combat
    if etat == "lancer" or etat == "mesure" or etat == "surveillance" then
      if poketch_visible() then sans_poketch = 0 else sans_poketch = sans_poketch + 1 end
      if sans_poketch >= 15 then
        etat, nb_combats = "combat", nb_combats + 1
        if CONFIG.pause_en_combat then pcall(emu.pause) end
      end
    end

    if etat == "lancer" then
      compteur = compteur - 1
      if compteur <= 0 then etat, compteur = "mesure", CONFIG.frames_mesure end

    elseif etat == "mesure" then
      if blancs > blancs_normal then blancs_normal = blancs end
      compteur = compteur - 1
      if compteur <= 0 then etat, compteur, vu = "surveillance", CONFIG.delai_max, 0 end

    elseif etat == "surveillance" then
      compteur = compteur - 1
      if texte_visible() then
        -- "Pas même une touche..." ou autre message : on ferme et on relance
        etat, essais_texte, compteur = "fermer_texte", 0, 0
      else
        if blancs >= blancs_normal + CONFIG.blancs_en_plus then vu = vu + 1 else vu = 0 end
        if vu >= CONFIG.frames_confirm then
          demander_appui("A")
          nb_A = nb_A + 1
          etat, compteur, sans_poketch = "apres_touche", CONFIG.attente_apres_A, 0
        elseif compteur <= 0 then
          etat, essais_texte, compteur = "fermer_texte", 0, 0
        end
      end

    elseif etat == "apres_touche" then
      -- Combat ou échec ? Si le Pokétch disparaît, c'est un combat.
      if poketch_visible() then sans_poketch = 0 else sans_poketch = sans_poketch + 1 end
      compteur = compteur - 1
      if sans_poketch >= 10 then
        etat, nb_combats = "combat", nb_combats + 1
        if CONFIG.pause_en_combat then pcall(emu.pause) end
      elseif texte_visible() and compteur < CONFIG.attente_apres_A - 10 then
        -- "Un Pokémon a mordu !" -> A pour lancer le combat
        -- (ou message d'échec -> A pour fermer, puis relance)
        etat, essais_texte, compteur = "fermer_texte", 0, 0
      elseif compteur <= 0 then
        etat, essais_texte, compteur = "fermer_texte", 0, 0
      end

    elseif etat == "fermer_texte" then
      -- surveille aussi un éventuel combat
      if poketch_visible() then sans_poketch = 0 else sans_poketch = sans_poketch + 1 end
      if sans_poketch >= 10 then
        etat, nb_combats = "combat", nb_combats + 1
        if CONFIG.pause_en_combat then pcall(emu.pause) end
      elseif compteur > 0 then
        compteur = compteur - 1
      elseif texte_visible() and essais_texte < 30 then
        -- A pour fermer le message ; un essai sur trois avec B au cas où A ne passe pas
        demander_appui((essais_texte % 3 == 2) and "B" or "A")
        essais_texte = essais_texte + 1
        compteur = 40           -- laisse le texte défiler
      elseif not texte_visible() then
        etat, compteur, sans_poketch = "relancer", 60, 0
      else
        etat = "attente"        -- texte vraiment bloqué (~25 s) : on laisse la main
      end

    elseif etat == "relancer" then
      if poketch_visible() and not texte_visible() then
        compteur = compteur - 1
        if compteur <= 0 then lancer_canne() end
      else
        sans_poketch = sans_poketch + 1
        if sans_poketch >= 30 then
          etat, nb_combats = "combat", nb_combats + 1
        end
      end

    elseif etat == "shiny" then
      -- Pause au moment des étoiles : on attend que la scène de combat soit affichée
      -- (boîte de texte visible), puis que des points clairs apparaissent autour de l'adversaire.
      if attente_etoiles then
        frames_shiny = frames_shiny + 1
        -- HGSS : pendant la glissade (ombre + grosses bulles blanches), la boîte de texte
        -- n'est pas encore là ; elle apparaît, vide, au moment des étoiles.
        if texte_visible() then
          frames_scene = frames_scene + 1
          local e = compter_etoiles()
          if e < base_etoiles then base_etoiles = e end
          if e >= base_etoiles + CONFIG.etoiles_seuil and e < N_ETOILES / 3 then
            vu_etoiles = vu_etoiles + 1
          else
            vu_etoiles = 0
          end
          if vu_etoiles >= 2 then
            attente_etoiles, pause_dans = false, CONFIG.delai_pause
          elseif texte_ecrit() or frames_scene >= CONFIG.etoiles_max then
            attente_etoiles, pause_dans = false, 0      -- étoiles non repérées : pause tout de suite
          end
        end
      end
      -- Le bot ne touche plus à rien. Retour sur la carte -> il attend ton Y.
      if poketch_visible() and not texte_visible() then retour_jeu = retour_jeu + 1 else retour_jeu = 0 end
      if retour_jeu >= CONFIG.fin_combat then etat, retour_jeu = "attente", 0 end

    elseif etat == "combat" then
      -- Tu as vérifié : Y = le bot fuit pour toi
      if Y_joueur then
        etat, etape_fuite, compteur, essais_fuite = "fuite", 0, 20, 0
      end
      -- Combat terminé (retour au jeu) : on relance la pêche tout seul
      if poketch_visible() and not texte_visible() then retour_jeu = retour_jeu + 1 else retour_jeu = 0 end
      if retour_jeu >= CONFIG.fin_combat then
        retour_jeu = 0
        lancer_canne()
      end

    elseif etat == "fuite" then
      -- On touche le bouton FUITE encore et encore jusqu'à la fin du combat
      -- (plusieurs appuis, au cas où le premier tombe au mauvais moment).
      essais_fuite = essais_fuite + 1
      if poketch_visible() then
        etat, retour_jeu, touche_ecran = "combat", 0, 0      -- sorti du combat
        pcall(stylus.set, { touch = false })
      elseif essais_fuite > 900 then
        etat = "combat"                                      -- 15 s sans succès : on rend la main
      elseif compteur > 0 then
        compteur = compteur - 1
      elseif touche_ecran == 0 then
        touche_ecran, touche_pos, compteur = 4, CONFIG.bouton_fuite, 12
      end

    -- "attente" : on ne fait rien, on attend un Y du joueur
    end
  end

  -- appui de touche en cours
  if actif and CONFIG.bloquer_Y then
    pcall(joypad.set, { Y = false })                -- pas de vélo quand tu appuies sur Y
  end
  if touche_a_tenir then
    presser(touche_a_tenir)
    frames_touche = frames_touche - 1
    if frames_touche <= 0 then touche_a_tenir = nil end
  end

  -- appui sur l'écran tactile en cours
  if touche_ecran > 0 then
    local pos = touche_pos or CONFIG.bouton_fuite
    pcall(stylus.set, { x = pos.x, y = pos.y, touch = true })
    touche_ecran = touche_ecran - 1
    if touche_ecran == 0 then pcall(stylus.set, { touch = false }); touche_pos = nil end
  end

  afficher()
  if pause_dans >= 0 then
    if pause_dans == 0 then pcall(emu.pause) end
    pause_dans = pause_dans - 1
  end
  emu.frameadvance()
  end
end
