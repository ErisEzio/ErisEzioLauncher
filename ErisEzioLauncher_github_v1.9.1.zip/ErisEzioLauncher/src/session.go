package main

import (
	"errors"
	"fmt"
	"os/exec"
	"path/filepath"
	"strconv"
	"strings"
	"syscall"
	"time"
)

// Paramètres d'une session de lancement.
type session struct {
	runAsDate, emulateur string
	n, parLigne          int
	depart               time.Time
	rom, romGBA          string
	tailleW, tailleH     int32
	pasForce             int32
	ecran                string // nom système de l'écran choisi ("" = le plus grand)
	ecart                int    // écart d'horloge entre deux fenêtres…
	unite                string // …dans cette unité : s, min, h, j, mois, an
}

// Horloge de la fenêtre i (0 = départ).
func horloge(depart time.Time, i, ecart int, unite string) time.Time {
	k := i * ecart
	switch unite {
	case "s":
		return depart.Add(time.Duration(k) * time.Second)
	case "h":
		return depart.Add(time.Duration(k) * time.Hour)
	case "j":
		return depart.AddDate(0, 0, k)
	case "mois":
		return depart.AddDate(0, k, 0)
	case "an":
		return depart.AddDate(k, 0, 0)
	}
	return depart.Add(time.Duration(k) * time.Minute)
}

// Format court d'une horloge selon l'unité de l'écart.
func formatHorloge(t time.Time, unite string) string {
	switch unite {
	case "s":
		return t.Format("15:04:05")
	case "j", "mois", "an":
		return t.Format("02/01/2006")
	}
	return t.Format("15:04")
}

// Prépare la session à partir du .ini de l'émulateur courant (réglages avancés).
func reglagesAvances(ini map[string]string, s *session) {
	if _, ok := ini["pasVertical"]; !ok {
		ini["pasVertical"] = "0"
	}
	if _, ok := ini["retoucheBordures"]; !ok {
		ini["retoucheBordures"] = "0"
	}
	if _, ok := ini["delaiLancement"]; !ok {
		ini["delaiLancement"] = "2"
	}
	retoucheBordures = ini["retoucheBordures"] == "1"
	delaiLancement = 2 * time.Second
	if v, err := strconv.ParseFloat(strings.ReplaceAll(ini["delaiLancement"], ",", "."), 64); err == nil && v >= 0 && v <= 60 {
		delaiLancement = time.Duration(v * float64(time.Second))
	}
	s.tailleW, s.tailleH = emu.clientW, emu.clientH
	if emu.cleIni == "mGBA" && strings.EqualFold(filepath.Ext(s.rom), ".gba") {
		s.tailleW, s.tailleH = 480, 358 // GBA en x2 : 480 x 320 + barre de menus (38 px)
	}
	if emu.clientW > 0 {
		// Taille par défaut (non personnalisée) : on suit le type de ROM.
		if v, ok := ini["tailleFenetre"]; !ok || v == "320x326" || v == "480x358" {
			ini["tailleFenetre"] = fmt.Sprintf("%dx%d", s.tailleW, s.tailleH)
		}
		var a, b int32
		if _, err := fmt.Sscanf(strings.ToLower(ini["tailleFenetre"]), "%dx%d", &a, &b); err == nil && a > 0 && b > 0 {
			s.tailleW, s.tailleH = a, b
		}
	}
	p, _ := strconv.Atoi(ini["pasVertical"])
	s.pasForce = int32(p)
}

// Lance les fenêtres et les range. etat() reçoit les messages, avance(i, n) la progression.
func lancerSession(s session, etat func(string), avance func(int, int)) error {
	nomMelon = filepath.Base(s.emulateur)
	ecran := choisirEcran(s.ecran)
	zone := ecran.RcWork

	connues := map[uintptr]bool{}
	for _, h := range fenetresMelon() {
		connues[h] = true // on ne touche pas aux émulateurs déjà ouverts
	}

	fen := make([]uintptr, s.n)
	var g grille
	grillePrete := false
	dossier := filepath.Dir(s.emulateur)

	ouvertes := 0
	for i := 0; i < s.n; i++ {
		if arret.Load() {
			break
		}
		t := horloge(s.depart, i, s.ecart, s.unite)
		etat(T("fenetreN", i+1, s.n, t.Format("02/01/2006"), t.Format("15:04:05")))
		avance(i, s.n)

		args := []string{"/movetime", t.Format(`02\01\2006`), t.Format("15:04:05"), s.emulateur}
		if botActif && len(argsBot) > 0 {
			args = append(args, argsBot...)
		}
		if s.rom != "" {
			if s.romGBA != "" && emu.gbaArg != "" {
				args = append(args, emu.gbaArg+s.romGBA)
			}
			args = append(args, s.rom)
			if s.romGBA != "" && emu.gbaArg == "" {
				args = append(args, s.romGBA)
			}
		}
		journal("Fenêtre %d/%d : RunAsDate %q", i+1, s.n, args)
		cmd := exec.Command(s.runAsDate, args...)
		cmd.Dir = dossier
		if err := cmd.Start(); err != nil {
			var en syscall.Errno
			if errors.As(err, &en) && en == errorElevationRequired {
				return errors.New(T("radAdmin"))
			}
			return errors.New(T("radLance", err.Error()))
		}
		go cmd.Wait()

		h := attendreNouvelleFenetre(connues)
		if h == 0 {
			journal("Fenêtre %d/%d : aucune fenêtre %s détectée en 30 s", i+1, s.n, nomMelon)
			continue
		}
		journal("Fenêtre %d/%d : détectée", i+1, s.n)
		connues[h] = true
		fen[i] = h
		ouvertes++
		time.Sleep(700 * time.Millisecond) // laisse l'émulateur finir d'afficher sa fenêtre
		redimensionner(h, s.tailleW, s.tailleH)

		if !grillePrete {
			r := rectVisible(h)
			w0, h0 := r.Right-r.Left, r.Bottom-r.Top
			if w0 < 50 || h0 < 50 {
				w0, h0 = 512, 880
			}
			pas := s.pasForce
			if pas == 0 && emu.pasMesure {
				pas = pasEcranHaut(h, r)
				journal("Décalage entre lignes mesuré : %d px (fenêtre %dx%d)", pas, w0, h0)
			}
			g = calculerGrille(s.n, s.parLigne, w0, h0, zone, pas)
			grillePrete = true
		}
		x, y := g.position(i)
		placer(h, x, y)
		ordonnerPlans(fen[:i+1])
		if i < s.n-1 {
			for fin := time.Now().Add(delaiLancement); time.Now().Before(fin) && !arret.Load(); {
				time.Sleep(100 * time.Millisecond)
			}
		}
	}
	avance(s.n, s.n)

	if !grillePrete {
		if arret.Load() {
			etat(T("arretAucune"))
			return nil
		}
		return errors.New(T("aucuneDetectee", emu.nom))
	}

	// Dernière passe : tout remettre en place et coller les zones d'affichage.
	etat(T("rangement"))
	time.Sleep(1500 * time.Millisecond)
	ok := 0
	for i, h := range fen {
		if h == 0 {
			continue
		}
		if v, _, _ := pIsWindow.Call(h); v == 0 {
			continue
		}
		redimensionner(h, s.tailleW, s.tailleH)
		x, y := g.position(i)
		placer(h, x, y)
		if col := i % g.cols; col > 0 && fen[i-1] != 0 {
			if v, _, _ := pIsWindow.Call(fen[i-1]); v != 0 {
				if dx := rectClient(fen[i-1]).Right - rectClient(h).Left; dx != 0 {
					placer(h, rectVisible(h).Left+dx, y)
				}
			}
		}
		ok++
	}
	ordonnerPlans(fen)
	if botActif && botMgbaClavier && !arret.Load() {
		etat(T("botChargement"))
		time.Sleep(1500 * time.Millisecond) // le temps que les jeux démarrent
		chargerScriptMgbaClavier(fen)
	}
	if botActif {
		masquerFenetresBot()
	}
	go func() { // certains émulateurs repassent devant en chargeant leur jeu : on revérifie
		for _, d := range []time.Duration{2 * time.Second, 5 * time.Second} {
			time.Sleep(d)
			ordonnerPlans(fen)
			if botActif {
				masquerFenetresBot()
			}
		}
	}()
	lignes := (s.n + g.cols - 1) / g.cols
	fin := horloge(s.depart, s.n-1, s.ecart, s.unite)
	if arret.Load() {
		ordonnerPlans(fen)
		etat(T("arretN", ouvertes, s.n))
		return nil
	}
	etat(T("termine",
		ok, s.n, lignes, g.cols, formatHorloge(s.depart, s.unite), formatHorloge(fin, s.unite)))
	return nil
}

// Décalage vertical qui laisse tout l'écran du haut visible, mesuré sur la fenêtre :
// hauteur visible jusqu'au bas de la zone d'affichage, moins l'écran du bas
// (largeur x 192/256). Tient compte de la barre d'outils de DeSmuME.
func pasEcranHaut(h uintptr, vis RECT) int32 {
	c := rectClient(h)
	largeur := c.Right - c.Left
	if largeur < 50 {
		return 0
	}
	ecranBas := int32(float64(largeur)*192/256 + 0.5)
	pas := c.Bottom - vis.Top - ecranBas
	if pas < 50 || pas >= vis.Bottom-vis.Top {
		return 0 // mesure incohérente : on garde le calcul habituel
	}
	return pas
}
