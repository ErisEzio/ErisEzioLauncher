package main

// Bot de pêche automatique pour DeSmuME (Pokémon Diamant / Perle / Platine).
//
// DeSmuME sait exécuter tout seul un script Lua au chargement d'une ROM :
// option [Scripting] AutoLoad=1 de desmume.ini, script nommé comme la ROM
// (sans extension) dans le dossier Lua de DeSmuME ([PathSettings] Lua,
// par défaut .\Lua à côté de l'exe). Le lanceur prépare donc ce script et
// active l'option ; chaque fenêtre ouverte démarre alors avec son bot.

import (
	_ "embed"
	"errors"
	"os"
	"path/filepath"
	"runtime"
	"strconv"
	"strings"
	"syscall"
	"time"
	"unsafe"
)

//go:embed peche_auto_desmume.lua
var scriptPecheIntegre []byte

//go:embed peche_auto_hgss.lua
var scriptPecheHGSS []byte

//go:embed peche_auto_bw.lua
var scriptPecheBW []byte

// Code de jeu de la ROM (4 caractères de l'en-tête, ex. "IPGF", "IREF")
func codeRom(rom string) string {
	f, err := os.Open(rom)
	if err != nil {
		return ""
	}
	defer f.Close()
	b := make([]byte, 4)
	if _, err := f.ReadAt(b, 0x0C); err != nil {
		return ""
	}
	return string(b)
}

// Vrai si le bot a été préparé pour la session en cours.
var botActif bool

var (
	pWritePrivateProfileStringW = kernel32.NewProc("WritePrivateProfileStringW")
	pGetPrivateProfileStringW   = kernel32.NewProc("GetPrivateProfileStringW")
)

func ecrireIniWindows(fichier, section, cle, valeur string) error {
	r, _, err := pWritePrivateProfileStringW.Call(
		uintptr(unsafe.Pointer(u16(section))), uintptr(unsafe.Pointer(u16(cle))),
		uintptr(unsafe.Pointer(u16(valeur))), uintptr(unsafe.Pointer(u16(fichier))))
	if r == 0 {
		return err
	}
	return nil
}

func lireIniWindows(fichier, section, cle string) string {
	buf := make([]uint16, 1024)
	pGetPrivateProfileStringW.Call(
		uintptr(unsafe.Pointer(u16(section))), uintptr(unsafe.Pointer(u16(cle))),
		uintptr(unsafe.Pointer(u16(""))), uintptr(unsafe.Pointer(&buf[0])), uintptr(len(buf)),
		uintptr(unsafe.Pointer(u16(fichier))))
	return syscall.UTF16ToString(buf)
}

// Dossier Lua utilisé par DeSmuME (réglage [PathSettings] Lua, sinon .\Lua).
func dossierLuaDesmume(dossierEmu, iniDsm string) string {
	p := strings.TrimSpace(lireIniWindows(iniDsm, "PathSettings", "Lua"))
	if p == "" || strings.EqualFold(p, "Lua") {
		p = `.\Lua`
	}
	if !filepath.IsAbs(p) {
		p = filepath.Join(dossierEmu, p)
	}
	return p
}

// Prépare (ou désactive) le bot pour DeSmuME. Renvoie le chemin du script installé
// ("" si le bot est désactivé).
func preparerBotDesmume(exeEmu, rom string, actif bool) (string, error) {
	dossier := filepath.Dir(exeEmu)
	iniDsm := filepath.Join(dossier, "desmume.ini")

	if !actif {
		if existe(iniDsm) {
			_ = ecrireIniWindows(iniDsm, "Scripting", "AutoLoad", "0")
		}
		return "", nil
	}
	if rom == "" {
		return "", errors.New(T("botSansRom"))
	}

	// Script : la version perso posée à côté de DeSmuME si elle existe, sinon celle intégrée.
	// Script : HGSS ou Diamant/Perle/Platine selon la ROM ; la version perso posée
	// à côté de DeSmuME est prise si elle existe, sinon celle intégrée.
	script, nomPerso := scriptPecheIntegre, "peche_auto_desmume.lua"
	switch code := codeRom(rom); {
	case strings.HasPrefix(code, "IPK"), strings.HasPrefix(code, "IPG"):
		script, nomPerso = scriptPecheHGSS, "peche_auto_hgss.lua" // HeartGold / SoulSilver
	case strings.HasPrefix(code, "IRB"), strings.HasPrefix(code, "IRA"),
		strings.HasPrefix(code, "IRE"), strings.HasPrefix(code, "IRD"):
		script, nomPerso = scriptPecheBW, "peche_auto_bw.lua" // Noire / Blanche / Noire 2 / Blanche 2
	}
	if perso := filepath.Join(dossier, nomPerso); existe(perso) {
		if b, err := os.ReadFile(perso); err == nil && len(b) > 0 {
			script = b
		}
	}

	dossierLua := dossierLuaDesmume(dossier, iniDsm)
	if err := os.MkdirAll(dossierLua, 0755); err != nil {
		return "", errors.New(T("botErreur", err.Error()))
	}
	nom := strings.TrimSuffix(filepath.Base(rom), filepath.Ext(rom)) + ".lua"
	cible := filepath.Join(dossierLua, nom)
	if err := os.WriteFile(cible, script, 0644); err != nil {
		return "", errors.New(T("botErreur", err.Error()))
	}
	// DeSmuME cherche le script avec un nom mal décodé quand la ROM contient des accents
	// (UTF-8 lu comme Windows-1252 : « Pokémon » devient « PokÃ©mon ») : on pose aussi cette copie.
	if double := nomMalDecode(nom); double != nom {
		_ = os.WriteFile(filepath.Join(dossierLua, double), script, 0644)
	}
	if err := ecrireIniWindows(iniDsm, "Scripting", "AutoLoad", "1"); err != nil {
		return "", errors.New(T("botErreur", err.Error()))
	}
	return cible, nil
}

// Les fenêtres « Lua Script » ouvertes par DeSmuME encombrent l'écran :
// on les cache (le script continue de tourner).
var (
	fenetresLua []uintptr
	enumLuaProc = syscall.NewCallback(func(h, lp uintptr) uintptr {
		if v, _, _ := pIsWindowVisible.Call(h); v == 0 {
			return 1
		}
		if o, _, _ := pGetWindow.Call(h, gwOwner); o == 0 {
			return 1 // seulement les fenêtres secondaires (dialogues)
		}
		buf := make([]uint16, 512)
		pGetWindowTextW.Call(h, uintptr(unsafe.Pointer(&buf[0])), uintptr(len(buf)))
		titre := strings.ToLower(syscall.UTF16ToString(buf))
		if !strings.HasSuffix(titre, ".lua") {
			return 1
		}
		var pid uint32
		pGetWindowThreadProcessId.Call(h, uintptr(unsafe.Pointer(&pid)))
		hp, _, _ := pOpenProcess.Call(processQueryLimitedInfo, 0, uintptr(pid))
		if hp == 0 {
			return 1
		}
		chemin := make([]uint16, 1024)
		sz := uint32(len(chemin))
		r, _, _ := pQueryFullProcessImageNameW.Call(hp, 0, uintptr(unsafe.Pointer(&chemin[0])), uintptr(unsafe.Pointer(&sz)))
		pCloseHandle.Call(hp)
		if r != 0 && strings.EqualFold(filepath.Base(syscall.UTF16ToString(chemin[:sz])), nomMelon) {
			fenetresLua = append(fenetresLua, h)
		}
		return 1
	})
)

func masquerFenetresLua() {
	fenetresLua = nil
	pEnumWindows.Call(enumLuaProc, 0)
	for _, h := range fenetresLua {
		pShowWindow.Call(h, 0) // SW_HIDE
	}
	if len(fenetresLua) > 0 {
		journal("Bot de pêche : %d fenêtre(s) Lua masquée(s)", len(fenetresLua))
	}
}

// Octets 0x80 à 0x9F de Windows-1252 (les autres octets donnent le même code Unicode).
var cp1252 = [32]rune{
	0x20AC, 0x81, 0x201A, 0x0192, 0x201E, 0x2026, 0x2020, 0x2021, 0x02C6, 0x2030, 0x0160, 0x2039, 0x0152, 0x8D, 0x017D, 0x8F,
	0x90, 0x2018, 0x2019, 0x201C, 0x201D, 0x2022, 0x2013, 0x2014, 0x02DC, 0x2122, 0x0161, 0x203A, 0x0153, 0x9D, 0x017E, 0x0178,
}

// Nom tel que DeSmuME le voit : octets UTF-8 interprétés en Windows-1252.
func nomMalDecode(s string) string {
	var b strings.Builder
	for i := 0; i < len(s); i++ {
		c := s[i]
		switch {
		case c >= 0x80 && c <= 0x9F:
			b.WriteRune(cp1252[c-0x80])
		default:
			b.WriteRune(rune(c))
		}
	}
	return b.String()
}

// ---------------------------------------------------------------------------
// Bot de pêche pour mGBA (Rubis / Saphir / Émeraude / Rouge Feu / Vert Feuille)
//
// mGBA 0.11 et plus : option --script, le bot démarre seul dans chaque fenêtre.
// mGBA 0.10 : pas de chargement automatique possible ; le script est ajouté en
// tête des « scripts récents » de mGBA pour le charger en deux clics.
// ---------------------------------------------------------------------------

//go:embed peche_auto_gba.lua
var scriptPecheGBA []byte

// Arguments à placer avant la ROM (ex. --script …) pour la session en cours.
var argsBot []string

// Avertissement mGBA 0.10 déjà affiché pendant cette exécution du launcher.
var infoMgbaVue bool

// Code de jeu d'une ROM GBA (en-tête 0xAC), "" si illisible (ROM zippée…).
func codeRomGBA(rom string) string {
	f, err := os.Open(rom)
	if err != nil {
		return ""
	}
	defer f.Close()
	b := make([]byte, 4)
	if _, err := f.ReadAt(b, 0xAC); err != nil {
		return ""
	}
	return string(b)
}

// Vrai si cet exe de mGBA connaît l'option --script (mGBA 0.11 et plus).
func mgbaAvecScript(exe string) bool {
	b, err := os.ReadFile(exe)
	if err != nil {
		return false
	}
	return strings.Contains(string(b), "--script FILE")
}

// Ajoute le script en tête de [recentScripts] dans qt.ini (dossier de config de mGBA).
func ajouterScriptRecentMgba(dossierEmu, script string) error {
	dossierCfg := dossierConfigMgba(dossierEmu)
	if err := os.MkdirAll(dossierCfg, 0755); err != nil {
		return err
	}
	qt := filepath.Join(dossierCfg, "qt.ini")
	script = filepath.ToSlash(script)

	var avant, apres []string
	var recents []string
	if b, err := os.ReadFile(qt); err == nil {
		lignes := strings.Split(strings.ReplaceAll(string(b), "\r\n", "\n"), "\n")
		dans, vue := false, false
		for _, l := range lignes {
			t := strings.TrimSpace(l)
			if strings.HasPrefix(t, "[") && strings.HasSuffix(t, "]") {
				dans = strings.EqualFold(t, "[recentScripts]")
				if dans {
					vue = true
					continue
				}
			}
			switch {
			case dans:
				if i := strings.Index(t, "="); i > 0 {
					v := strings.TrimSpace(t[i+1:])
					if v != "" && !strings.EqualFold(filepath.ToSlash(v), script) {
						recents = append(recents, v)
					}
				}
			case vue:
				apres = append(apres, l)
			default:
				avant = append(avant, l)
			}
		}
	}
	for len(avant) > 0 && strings.TrimSpace(avant[len(avant)-1]) == "" {
		avant = avant[:len(avant)-1]
	}
	section := []string{"[recentScripts]", "0=" + script}
	for i, v := range recents {
		if i >= 9 {
			break
		}
		section = append(section, strconv.Itoa(i+1)+"="+v)
	}
	var tout []string
	if len(avant) > 0 {
		tout = append(tout, avant...)
		tout = append(tout, "")
	}
	tout = append(tout, section...)
	tout = append(tout, "")
	tout = append(tout, apres...)
	return os.WriteFile(qt, []byte(strings.TrimRight(strings.Join(tout, "\r\n"), "\r\n")+"\r\n"), 0644)
}

// Prépare le bot pour mGBA. Renvoie le chemin du script ("" si désactivé).
func preparerBotMgba(exeEmu, rom string, actif bool) (string, error) {
	argsBot = nil
	botMgbaClavier = false
	if !actif {
		return "", nil
	}
	if rom == "" {
		return "", errors.New(T("botSansRom"))
	}
	if code := codeRomGBA(rom); code != "" {
		ok := false
		for _, p := range []string{"BPE", "BPR", "BPG", "AXV", "AXP"} {
			if strings.HasPrefix(code, p) {
				ok = true
			}
		}
		if !ok && strings.EqualFold(filepath.Ext(rom), ".gba") {
			return "", errors.New(T("botGbaJeu"))
		}
	}

	dossier := filepath.Dir(exeEmu)
	script := scriptPecheGBA
	if perso := filepath.Join(dossier, "peche_auto_gba.lua"); existe(perso) {
		if b, err := os.ReadFile(perso); err == nil && len(b) > 0 {
			script = b
		}
	}
	dossierScripts := filepath.Join(dossier, "scripts")
	if err := os.MkdirAll(dossierScripts, 0755); err != nil {
		return "", errors.New(T("botErreur", err.Error()))
	}
	cible := filepath.Join(dossierScripts, "bot_peche_gba.lua")
	if err := os.WriteFile(cible, script, 0644); err != nil {
		return "", errors.New(T("botErreur", err.Error()))
	}

	if mgbaAvecScript(exeEmu) {
		argsBot = []string{"--script", cible}
		return cible, nil
	}
	if err := ajouterScriptRecentMgba(dossier, cible); err != nil {
		journal("Bot de pêche : qt.ini non modifié (%v)", err)
		if !infoMgbaVue {
			infoMgbaVue = true
			boite(T("bot"), T("botMgba010"), 0x40)
		}
		return cible, nil
	}
	qt := filepath.Join(dossierConfigMgba(dossier), "qt.ini")
	if err := ecrireQtIni(qt, "shortcutKey", "scripting", raccourciScripting); err != nil {
		journal("Bot de pêche : raccourci Scripting non écrit (%v)", err)
		return cible, nil
	}
	botMgbaClavier = true
	return cible, nil
}

// Titre de fenêtre commençant par « Script » (console de scripts de mGBA).
func estFenetreScript(h uintptr) bool {
	buf := make([]uint16, 256)
	pGetWindowTextW.Call(h, uintptr(unsafe.Pointer(&buf[0])), uintptr(len(buf)))
	return strings.HasPrefix(strings.ToLower(syscall.UTF16ToString(buf)), "script")
}

// Cache les fenêtres « Scripting » ouvertes par mGBA avec --script (le bot continue).
var (
	fenetresScript []uintptr
	enumScriptProc = syscall.NewCallback(func(h, lp uintptr) uintptr {
		if v, _, _ := pIsWindowVisible.Call(h); v == 0 || !estFenetreScript(h) {
			return 1
		}
		var pid uint32
		pGetWindowThreadProcessId.Call(h, uintptr(unsafe.Pointer(&pid)))
		hp, _, _ := pOpenProcess.Call(processQueryLimitedInfo, 0, uintptr(pid))
		if hp == 0 {
			return 1
		}
		chemin := make([]uint16, 1024)
		sz := uint32(len(chemin))
		r, _, _ := pQueryFullProcessImageNameW.Call(hp, 0, uintptr(unsafe.Pointer(&chemin[0])), uintptr(unsafe.Pointer(&sz)))
		pCloseHandle.Call(hp)
		if r != 0 && strings.EqualFold(filepath.Base(syscall.UTF16ToString(chemin[:sz])), nomMelon) {
			fenetresScript = append(fenetresScript, h)
		}
		return 1
	})
)

func masquerFenetresScript() {
	fenetresScript = nil
	pEnumWindows.Call(enumScriptProc, 0)
	for _, h := range fenetresScript {
		pShowWindow.Call(h, 0) // SW_HIDE
	}
	if len(fenetresScript) > 0 {
		journal("Bot de pêche : %d fenêtre(s) Scripting masquée(s)", len(fenetresScript))
	}
}

// Masque les fenêtres de script de l'émulateur en cours.
func masquerFenetresBot() {
	if emu.cleIni == "DeSmuME" {
		masquerFenetresLua()
	} else if emu.cleIni == "mGBA" {
		masquerFenetresScript()
	}
}

// ---------------------------------------------------------------------------
// mGBA 0.10 : chargement automatique du script dans chaque fenêtre.
// mGBA 0.10 n'a pas d'option --script : le launcher ouvre lui-même, dans chaque
// fenêtre, Outils > Scripting (raccourci Ctrl+Maj+F9 ajouté dans qt.ini), puis
// File > Load recent script > 1er script (le bot, placé en tête de la liste).
// ---------------------------------------------------------------------------

const raccourciScripting = "Ctrl+Shift+F9"

// Vrai si les fenêtres mGBA de la session doivent recevoir le script au clavier.
var botMgbaClavier bool

var (
	pSetForegroundWindow = user32.NewProc("SetForegroundWindow")
	pGetForegroundWindow = user32.NewProc("GetForegroundWindow")
	pAttachThreadInput   = user32.NewProc("AttachThreadInput")
	pKeybdEvent          = user32.NewProc("keybd_event")
	pBringWindowToTop    = user32.NewProc("BringWindowToTop")
	pGetCurrentThreadId  = kernel32.NewProc("GetCurrentThreadId")
)

const (
	vkMenu    = 0x12
	vkControl = 0x11
	vkShift   = 0x10
	vkF9      = 0x78
	vkDown    = 0x28
	vkRight   = 0x27
	vkReturn  = 0x0D
	keyUp     = 0x0002
	keyExt    = 0x0001
)

func touche(vk uintptr, haut bool) {
	f := uintptr(0)
	if vk == vkDown || vk == vkRight {
		f |= keyExt
	}
	if haut {
		f |= keyUp
	}
	pKeybdEvent.Call(vk, 0, f, 0)
}

func taper(vk uintptr) {
	touche(vk, false)
	time.Sleep(40 * time.Millisecond)
	touche(vk, true)
	time.Sleep(160 * time.Millisecond)
}

// Met la fenêtre au premier plan (en s'attachant au fil de la fenêtre active).
func premierPlan(h uintptr) bool {
	runtime.LockOSThread()
	defer runtime.UnlockOSThread()
	fg, _, _ := pGetForegroundWindow.Call()
	moi, _, _ := pGetCurrentThreadId.Call()
	var lui uintptr
	if fg != 0 {
		lui, _, _ = pGetWindowThreadProcessId.Call(fg, 0)
	}
	if lui != 0 && lui != moi {
		pAttachThreadInput.Call(moi, lui, 1)
		defer pAttachThreadInput.Call(moi, lui, 0)
	}
	if pIsIconic != nil {
		if r, _, _ := pIsIconic.Call(h); r != 0 {
			pShowWindow.Call(h, 9) // SW_RESTORE
		}
	}
	pBringWindowToTop.Call(h)
	pSetForegroundWindow.Call(h)
	time.Sleep(200 * time.Millisecond)
	now, _, _ := pGetForegroundWindow.Call()
	return now == h
}

func pidFenetre(h uintptr) uint32 {
	var pid uint32
	pGetWindowThreadProcessId.Call(h, uintptr(unsafe.Pointer(&pid)))
	return pid
}

// Fenêtre « Scripting » visible du même processus que h (0 si aucune).
func fenetreScriptDe(h uintptr) uintptr {
	pid := pidFenetre(h)
	fenetresScript = nil
	pEnumWindows.Call(enumScriptProc, 0)
	for _, s := range fenetresScript {
		if pidFenetre(s) == pid {
			return s
		}
	}
	return 0
}

// Charge le bot dans chaque fenêtre mGBA 0.10 en pilotant ses menus au clavier.
func chargerScriptMgbaClavier(fen []uintptr) {
	ok := 0
	for i, h := range fen {
		if h == 0 {
			continue
		}
		if v, _, _ := pIsWindow.Call(h); v == 0 {
			continue
		}
		reussi := false
		for essai := 0; essai < 2 && !reussi; essai++ {
			if !premierPlan(h) {
				journal("Bot de pêche : fenêtre %d pas au premier plan", i+1)
			}
			// Outils > Scripting… (raccourci)
			touche(vkControl, false)
			touche(vkShift, false)
			taper(vkF9)
			touche(vkShift, true)
			touche(vkControl, true)
			var s uintptr
			for t := 0; t < 30 && s == 0; t++ {
				time.Sleep(100 * time.Millisecond)
				s = fenetreScriptDe(h)
			}
			if s == 0 {
				continue
			}
			premierPlan(s)
			time.Sleep(250 * time.Millisecond)
			// File > Load recent script > 1er script
			taper(vkMenu)
			taper(vkDown)
			taper(vkDown)
			taper(vkRight)
			time.Sleep(150 * time.Millisecond)
			taper(vkReturn)
			time.Sleep(400 * time.Millisecond)
			pShowWindow.Call(s, 0) // SW_HIDE : le bot continue de tourner
			reussi = true
		}
		if reussi {
			ok++
		}
	}
	journal("Bot de pêche : script chargé au clavier dans %d/%d fenêtre(s)", ok, len(fen))
	if len(fen) > 0 {
		ordonnerPlans(fen)
	}
}

// Écrit cle=valeur dans la section donnée de qt.ini (crée la section au besoin).
func ecrireQtIni(qt, section, cle, valeur string) error {
	var lignes []string
	if b, err := os.ReadFile(qt); err == nil {
		lignes = strings.Split(strings.ReplaceAll(string(b), "\r\n", "\n"), "\n")
	}
	tete := "[" + section + "]"
	debut := -1
	for i, l := range lignes {
		if strings.EqualFold(strings.TrimSpace(l), tete) {
			debut = i
			break
		}
	}
	if debut < 0 {
		for len(lignes) > 0 && strings.TrimSpace(lignes[len(lignes)-1]) == "" {
			lignes = lignes[:len(lignes)-1]
		}
		if len(lignes) > 0 {
			lignes = append(lignes, "")
		}
		lignes = append(lignes, tete, cle+"="+valeur)
	} else {
		fin := len(lignes)
		for j := debut + 1; j < len(lignes); j++ {
			t := strings.TrimSpace(lignes[j])
			if strings.HasPrefix(t, "[") && strings.HasSuffix(t, "]") {
				fin = j
				break
			}
		}
		remplace := false
		for j := debut + 1; j < fin; j++ {
			if k := strings.Index(lignes[j], "="); k > 0 && strings.EqualFold(strings.TrimSpace(lignes[j][:k]), cle) {
				lignes[j] = cle + "=" + valeur
				remplace = true
			}
		}
		if !remplace {
			nouv := append([]string{}, lignes[:debut+1]...)
			nouv = append(nouv, cle+"="+valeur)
			lignes = append(nouv, lignes[debut+1:]...)
		}
	}
	return os.WriteFile(qt, []byte(strings.TrimRight(strings.Join(lignes, "\r\n"), "\r\n")+"\r\n"), 0644)
}

// Dossier de configuration de mGBA (portable si portable.ini est à côté de l'exe).
func dossierConfigMgba(dossierEmu string) string {
	if existe(filepath.Join(dossierEmu, "portable.ini")) {
		return dossierEmu
	}
	return filepath.Join(os.Getenv("APPDATA"), "mGBA")
}
