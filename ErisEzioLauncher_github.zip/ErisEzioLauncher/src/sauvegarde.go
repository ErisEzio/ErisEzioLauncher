package main

import (
	"bytes"
	"errors"
	"os"
	"path/filepath"
	"strings"
	"time"
)

// Extensions reconnues comme sauvegardes lors d'un glisser-déposer.
func estSauvegarde(p string) bool {
	switch strings.ToLower(filepath.Ext(p)) {
	case ".sav", ".dsv", ".srm":
		return true
	}
	return false
}

// Fichier de sauvegarde que l'émulateur lit pour cette ROM : même dossier, même nom, en .sav.
func cibleSauvegarde(rom string) string {
	return strings.TrimSuffix(rom, filepath.Ext(rom)) + ".sav"
}

// Installe la sauvegarde choisie pour la ROM : l'ancienne est d'abord mise de côté
// (nom.sav.bak-AAAAMMJJ-HHMMSS), puis la nouvelle est copiée à sa place.
// Les .dsv de DeSmuME sont convertis en .sav brut (pied de page retiré).
func installerSauvegarde(sav, rom string) (string, error) {
	if rom == "" {
		return "", errors.New("Choisis d'abord la ROM du jeu pour pouvoir utiliser cette sauvegarde.")
	}
	donnees, err := os.ReadFile(sav)
	if err != nil {
		return "", errors.New("Impossible de lire la sauvegarde : " + err.Error())
	}
	if strings.EqualFold(filepath.Ext(sav), ".dsv") {
		if i := bytes.Index(donnees, []byte("|<--Snip above here")); i > 0 {
			donnees = donnees[:i]
		}
	}
	cible := cibleSauvegarde(rom)
	if filepath.Clean(cible) == filepath.Clean(sav) {
		return "", nil // c'est déjà la sauvegarde par défaut
	}
	copie := ""
	if anciennes, err := os.ReadFile(cible); err == nil {
		copie = cible + ".bak-" + time.Now().Format("20060102-150405")
		if err := os.WriteFile(copie, anciennes, 0644); err != nil {
			return "", errors.New("Impossible de mettre l'ancienne sauvegarde de côté : " + err.Error())
		}
	}
	if err := os.WriteFile(cible, donnees, 0644); err != nil {
		return "", errors.New("Impossible d'installer la sauvegarde : " + err.Error())
	}
	return copie, nil
}
