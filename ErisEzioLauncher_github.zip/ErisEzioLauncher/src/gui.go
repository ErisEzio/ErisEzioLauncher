package main

// Interface Win32 inspirée du menu de la Nintendo DS : fond quadrillé, barres
// grises en haut et en bas, cartes blanches à bords arrondis, carte active en bleu.

import (
	"fmt"
	"os"
	"path/filepath"
	"runtime"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"syscall"
	"time"
	"unsafe"
)

func init() { runtime.LockOSThread() } // la fenêtre vit sur le fil principal

var (
	gdi32    = syscall.NewLazyDLL("gdi32.dll")
	comctl32 = syscall.NewLazyDLL("comctl32.dll")
	comdlg32 = syscall.NewLazyDLL("comdlg32.dll")

	pRegisterClassExW   = user32.NewProc("RegisterClassExW")
	pCreateWindowExW    = user32.NewProc("CreateWindowExW")
	pDefWindowProcW     = user32.NewProc("DefWindowProcW")
	pGetMessageW        = user32.NewProc("GetMessageW")
	pTranslateMessage   = user32.NewProc("TranslateMessage")
	pDispatchMessageW   = user32.NewProc("DispatchMessageW")
	pIsDialogMessageW   = user32.NewProc("IsDialogMessageW")
	pPostQuitMessage    = user32.NewProc("PostQuitMessage")
	pPostMessageW       = user32.NewProc("PostMessageW")
	pSendMessageW       = user32.NewProc("SendMessageW")
	pMoveWindow         = user32.NewProc("MoveWindow")
	pEnableWindow       = user32.NewProc("EnableWindow")
	pIsWindowEnabled    = user32.NewProc("IsWindowEnabled")
	pGetWindowTextW     = user32.NewProc("GetWindowTextW")
	pLoadCursorW        = user32.NewProc("LoadCursorW")
	pLoadImageW         = user32.NewProc("LoadImageW")
	pMessageBoxW        = user32.NewProc("MessageBoxW")
	pAdjustWindowRectEx = user32.NewProc("AdjustWindowRectEx")
	pGetDpiForSystem    = user32.NewProc("GetDpiForSystem")
	pGetDpiForWindow    = user32.NewProc("GetDpiForWindow")
	pAdjustRectForDpi   = user32.NewProc("AdjustWindowRectExForDpi")
	pDestroyIcon        = user32.NewProc("DestroyIcon")
	pGetSystemMetrics   = user32.NewProc("GetSystemMetrics")
	pInvalidateRect     = user32.NewProc("InvalidateRect")
	pBeginPaint         = user32.NewProc("BeginPaint")
	pEndPaint           = user32.NewProc("EndPaint")
	pFillRect           = user32.NewProc("FillRect")
	pDrawTextW          = user32.NewProc("DrawTextW")
	pDrawIconEx         = user32.NewProc("DrawIconEx")
	pSetTimer           = user32.NewProc("SetTimer")
	pGetModuleHandleW   = kernel32.NewProc("GetModuleHandleW")
	pCreateFontW        = gdi32.NewProc("CreateFontW")
	pCreateSolidBrush   = gdi32.NewProc("CreateSolidBrush")
	pCreatePen          = gdi32.NewProc("CreatePen")
	pSelectObject       = gdi32.NewProc("SelectObject")
	pDeleteObject       = gdi32.NewProc("DeleteObject")
	pRoundRect          = gdi32.NewProc("RoundRect")
	pSetTextColor       = gdi32.NewProc("SetTextColor")
	pSetBkColor         = gdi32.NewProc("SetBkColor")
	pSetBkMode          = gdi32.NewProc("SetBkMode")
	pCreateCompatDC     = gdi32.NewProc("CreateCompatibleDC")
	pCreateCompatBmp    = gdi32.NewProc("CreateCompatibleBitmap")
	pBitBlt             = gdi32.NewProc("BitBlt")
	pDeleteDC           = gdi32.NewProc("DeleteDC")
	pInitCommonCtrlsEx  = comctl32.NewProc("InitCommonControlsEx")
	pGetOpenFileNameW   = comdlg32.NewProc("GetOpenFileNameW")
	pDragAcceptFiles    = shell32.NewProc("DragAcceptFiles")
	pDragQueryFileW     = shell32.NewProc("DragQueryFileW")
	pDragFinish         = shell32.NewProc("DragFinish")
)

const (
	wsChild         = 0x40000000
	wsVisible       = 0x10000000
	wsTabStop       = 0x00010000
	wsCaption       = 0x00C00000
	wsSysMenu       = 0x00080000
	wsMinimizeBox   = 0x00020000
	wsClipChildren  = 0x02000000
	wsVScroll       = 0x00200000
	wsExClient      = 0x00000200
	wsExAccept      = 0x00000010
	esNumber        = 0x2000
	esAutoHScroll   = 0x0080
	esCenter        = 0x0001
	cbsDropList     = 0x0003
	bsOwnerDraw     = 0x000B
	udsBuddyInt     = 0x0002
	udsRight        = 0x0004
	udsArrows       = 0x0020
	udsNoThousands  = 0x0080
	dtsTimeFormat   = 0x0009
	wmDestroy       = 0x0002
	wmPaint         = 0x000F
	wmEraseBkgnd    = 0x0014
	wmSetFont       = 0x0030
	wmDrawItem      = 0x002B
	wmCommand       = 0x0111
	wmTimer         = 0x0113
	wmCtlColorStat  = 0x0138
	wmCtlColorEdit  = 0x0133
	wmDropFiles     = 0x0233
	wmApp           = 0x8000
	cbAddString     = 0x0143
	cbGetCurSel     = 0x0147
	cbSetCurSel     = 0x014E
	cbnSelChange    = 1
	bnClicked       = 0
	udmSetBuddy     = 0x0469
	udmSetRange32   = 0x046F
	udmSetPos32     = 0x0471
	dtmGetSystemTim = 0x1001
	dtmSetSystemTim = 0x1002
	dtmSetFormatW   = 0x1032
	dtCenter        = 0x0001
	dtVCenter       = 0x0004
	dtSingleLine    = 0x0020
	dtEndEllipsis   = 0x8000
	dtNoPrefix      = 0x0800
	odsSelected     = 0x0001
	odsDisabled     = 0x0004
	odsFocus        = 0x0010

	idCombo  = 101
	idLancer = 102
	idRom    = 103
	idRomX   = 104
	idGba    = 105
	idGbaX   = 106
	idSav    = 107
	idSavX   = 108
	msgFini  = wmApp + 1
	resIcone = 2 // groupe d'icônes intégré (après le manifeste)
)

// Couleurs façon menu DS (format Windows 0x00BBGGRR).
func rgb(r, g, b uint32) uintptr { return uintptr(r | g<<8 | b<<16) }

var (
	cFond       = rgb(255, 255, 255)
	cGrille     = rgb(232, 232, 232)
	cBarre      = rgb(222, 224, 228)
	cBarreBord  = rgb(160, 164, 170)
	cCarte      = rgb(255, 255, 255)
	cCarteBord  = rgb(170, 170, 170)
	cActif      = rgb(60, 110, 180)
	cActifClair = rgb(168, 200, 232)
	cTexte      = rgb(48, 48, 48)
	cDiscret    = rgb(128, 128, 128)
	cRose       = rgb(206, 60, 96)
	cBleu       = rgb(48, 96, 192)
	cBouton     = rgb(244, 246, 250)
	cBoutonBas  = rgb(214, 226, 242)
)

type wndClassEx struct {
	cbSize        uint32
	style         uint32
	lpfnWndProc   uintptr
	cbClsExtra    int32
	cbWndExtra    int32
	hInstance     uintptr
	hIcon         uintptr
	hCursor       uintptr
	hbrBackground uintptr
	lpszMenuName  *uint16
	lpszClassName *uint16
	hIconSm       uintptr
}

type msgW struct {
	hwnd    uintptr
	message uint32
	wParam  uintptr
	lParam  uintptr
	time    uint32
	ptX     int32
	ptY     int32
	private uint32
}

type paintStruct struct {
	hdc        uintptr
	fErase     int32
	rcPaint    RECT
	fRestore   int32
	fIncUpdate int32
	reserved   [32]byte
}

type drawItem struct {
	CtlType    uint32
	CtlID      uint32
	itemID     uint32
	itemAction uint32
	itemState  uint32
	hwndItem   uintptr
	hDC        uintptr
	rcItem     RECT
	itemData   uintptr
}

type systemTime struct {
	Year, Month, DayOfWeek, Day, Hour, Minute, Second, Ms uint16
}

type openFileName struct {
	lStructSize       uint32
	hwndOwner         uintptr
	hInstance         uintptr
	lpstrFilter       *uint16
	lpstrCustomFilter *uint16
	nMaxCustFilter    uint32
	nFilterIndex      uint32
	lpstrFile         *uint16
	nMaxFile          uint32
	lpstrFileTitle    *uint16
	nMaxFileTitle     uint32
	lpstrInitialDir   *uint16
	lpstrTitle        *uint16
	Flags             uint32
	nFileOffset       uint16
	nFileExtension    uint16
	lpstrDefExt       *uint16
	lCustData         uintptr
	lpfnHook          uintptr
	lpTemplateName    *uint16
	pvReserved        uintptr
	dwReserved        uint32
	FlagsEx           uint32
}

// Une carte dessinée sur le fond quadrillé.
type carte struct {
	x, y, w, h int // coordonnées logiques (96 ppp)
	titre      string
	couleur    uintptr
	active     bool
	texte      string // contenu affiché (nom de fichier…), vide = aucun
	texteVide  string
}

// ---------- état ----------

var (
	hInst, hwndMain                       uintptr
	echelle                               = 1.0
	fNormal, fPetit, fTitre, fGros, fMini uintptr
	icone44                               uintptr
	cbEmu, edN, udN, edL, udL             uintptr
	dtDate, dtHeure                       uintptr
	btRom, btRomX, btGba, btGbaX          uintptr
	btSav, btSavX, btLancer               uintptr
	ckDecal                               uintptr
	cheminRom, cheminGba, cheminSav       string
	cartes                                []carte
	hauteurClient                         int
	enCours                               bool
	verrou                                sync.Mutex
	etatTexte                             = "Prêt — glisse une ROM ou une sauvegarde sur la fenêtre."
	progI, progN                          int
	erreurSession                         string
)

const largeurClient = 440

func u16(s string) *uint16 { p, _ := syscall.UTF16PtrFromString(s); return p }
func px(v int) int32       { return int32(float64(v)*echelle + 0.5) }

func envoyer(h uintptr, m uint32, w, l uintptr) uintptr {
	r, _, _ := pSendMessageW.Call(h, uintptr(m), w, l)
	return r
}

func texteDe(h uintptr) string {
	buf := make([]uint16, 256)
	pGetWindowTextW.Call(h, uintptr(unsafe.Pointer(&buf[0])), uintptr(len(buf)))
	return syscall.UTF16ToString(buf)
}

func controle(classe, txt string, style, exStyle uint32, id int, police uintptr) uintptr {
	h, _, _ := pCreateWindowExW.Call(uintptr(exStyle), uintptr(unsafe.Pointer(u16(classe))),
		uintptr(unsafe.Pointer(u16(txt))), uintptr(style|wsChild|wsVisible),
		0, 0, 10, 10, hwndMain, uintptr(id), hInst, 0)
	if police != 0 {
		envoyer(h, wmSetFont, police, 1)
	}
	return h
}

func police(taille, gras int, nom string) uintptr {
	h, _, _ := pCreateFontW.Call(uintptr(-px(taille)), 0, 0, 0, uintptr(gras), 0, 0, 0, 1, 0, 0, 5, 0,
		uintptr(unsafe.Pointer(u16(nom))))
	return h
}

func boite(titre, txt string, icone uint32) {
	pMessageBoxW.Call(hwndMain, uintptr(unsafe.Pointer(u16(txt))), uintptr(unsafe.Pointer(u16(titre))), uintptr(icone))
}

func place(h uintptr, x, y, w, ht int) {
	pMoveWindow.Call(h, uintptr(px(x)), uintptr(px(y)), uintptr(px(w)), uintptr(px(ht)), 1)
}

func montrer(h uintptr, oui bool) {
	v := uintptr(0)
	if oui {
		v = 5
	}
	pShowWindow.Call(h, v)
}

func redessiner() { pInvalidateRect.Call(hwndMain, 0, 0) }

func definirEtat(s string) {
	verrou.Lock()
	etatTexte = s
	verrou.Unlock()
	redessiner()
}

// ---------- disposition ----------

func disposer() {
	cartes = cartes[:0]
	x, w := 16, largeurClient-32
	demi := (w - 8) / 2
	y := 38

	// Carte d'en-tête (active, comme la cartouche insérée sur la DS).
	cartes = append(cartes, carte{x: x, y: y, w: w, h: 70, active: true})
	y += 80

	cartes = append(cartes, carte{x: x, y: y, w: w, h: 62, titre: "ÉMULATEUR", couleur: cDiscret})
	place(cbEmu, x+12, y+26, w-24, 300)
	y += 72

	cartes = append(cartes, carte{x: x, y: y, w: demi, h: 62, titre: "FENÊTRES", couleur: cDiscret},
		carte{x: x + demi + 8, y: y, w: demi, h: 62, titre: "PAR LIGNE", couleur: cDiscret})
	place(edN, x+12, y+26, demi-24, 26)
	place(edL, x+demi+20, y+26, demi-24, 26)
	envoyer(udN, udmSetBuddy, edN, 0)
	envoyer(udL, udmSetBuddy, edL, 0)
	y += 72

	cartes = append(cartes, carte{x: x, y: y, w: demi, h: 62, titre: "DATE", couleur: cRose},
		carte{x: x + demi + 8, y: y, w: demi, h: 62, titre: "HEURE", couleur: cBleu})
	place(dtDate, x+12, y+26, demi-24, 26)
	place(dtHeure, x+demi+20, y+26, demi-24, 26)
	y += 72

	cartes = append(cartes, carte{x: x, y: y, w: w, h: 50, titre: "DISPOSITION", couleur: cDiscret})
	place(ckDecal, x+12, y+22, w-24, 22)
	y += 60

	bouton := func(b1, b2 uintptr, yy int) {
		place(b1, x+w-12-62, yy+26, 28, 26)
		place(b2, x+w-12-28, yy+26, 28, 26)
	}
	cartes = append(cartes, carte{x: x, y: y, w: w, h: 62, titre: "ROM DU JEU", couleur: cDiscret,
		texte: nomFichier(cheminRom), texteVide: "Aucune ROM — glisse un fichier ici."})
	bouton(btRom, btRomX, y)
	y += 72

	melon := variante == "melonds"
	for _, h := range []uintptr{btGba, btGbaX} {
		montrer(h, melon)
	}
	if melon {
		cartes = append(cartes, carte{x: x, y: y, w: w, h: 62, titre: "CARTOUCHE GBA", couleur: cDiscret,
			texte: nomFichier(cheminGba), texteVide: "Aucune cartouche GBA insérée."})
		bouton(btGba, btGbaX, y)
		y += 72
	}

	azahar := variante == "azahar"
	vide := "Sauvegarde par défaut du jeu."
	if azahar {
		vide = "Non disponible pour Azahar (sauvegardes internes)."
	}
	cartes = append(cartes, carte{x: x, y: y, w: w, h: 62, titre: "SAUVEGARDE", couleur: cDiscret,
		texte: nomFichier(cheminSav), texteVide: vide})
	bouton(btSav, btSavX, y)
	pEnableWindow.Call(btSav, boolPtr(!azahar && !enCours))
	pEnableWindow.Call(btSavX, boolPtr(!azahar && !enCours))
	y += 74

	place(btLancer, x, y, w, 58)
	y += 58 + 14

	hauteurClient = y + 30 // barre du bas
	r := RECT{0, 0, px(largeurClient), px(hauteurClient)}
	if pAdjustRectForDpi.Find() == nil {
		pAdjustRectForDpi.Call(uintptr(unsafe.Pointer(&r)), wsCaption|wsSysMenu|wsMinimizeBox, 0, 0, uintptr(dpiCourant()))
	} else {
		pAdjustWindowRectEx.Call(uintptr(unsafe.Pointer(&r)), wsCaption|wsSysMenu|wsMinimizeBox, 0, 0)
	}
	pSetWindowPos.Call(hwndMain, 0, 0, 0, uintptr(r.Right-r.Left), uintptr(r.Bottom-r.Top),
		swpNoMove|swpNoZOrderFlag|swpNoActivate)
	redessiner()
}

func dpiCourant() int32 { return int32(echelle*96 + 0.5) }

// (Re)crée polices et icône à l'échelle de l'écran courant et les applique aux contrôles.
func appliquerEchelle() {
	anciennes := []uintptr{fNormal, fPetit, fMini, fTitre, fGros}
	fNormal = police(15, 400, "Segoe UI")
	fPetit = police(13, 400, "Segoe UI")
	fMini = police(11, 700, "Segoe UI")
	fTitre = police(20, 600, "Segoe UI Semibold")
	fGros = police(20, 700, "Segoe UI")
	for _, h := range []uintptr{cbEmu, edN, edL, dtDate, dtHeure, btRom, btRomX, btGba, btGbaX, btSav, btSavX, ckDecal} {
		if h != 0 {
			envoyer(h, wmSetFont, fNormal, 1)
		}
	}
	if btLancer != 0 {
		envoyer(btLancer, wmSetFont, fGros, 1)
	}
	for _, f := range anciennes {
		if f != 0 {
			pDeleteObject.Call(f)
		}
	}
	if icone44 != 0 {
		pDestroyIcon.Call(icone44)
	}
	icone44, _, _ = pLoadImageW.Call(hInst, resIcone, 1, uintptr(px(44)), uintptr(px(44)), 0)
}

func boolPtr(b bool) uintptr {
	if b {
		return 1
	}
	return 0
}

func nomFichier(p string) string {
	if p == "" {
		return ""
	}
	return filepath.Base(p)
}

// ---------- dessin ----------

func remplir(dc uintptr, r RECT, c uintptr) {
	b, _, _ := pCreateSolidBrush.Call(c)
	pFillRect.Call(dc, uintptr(unsafe.Pointer(&r)), b)
	pDeleteObject.Call(b)
}

func rect(x, y, w, h int) RECT { return RECT{px(x), px(y), px(x + w), px(y + h)} }

func arrondi(dc uintptr, r RECT, fond, bord uintptr, epais int, rayon int) {
	pen, _, _ := pCreatePen.Call(0, uintptr(px(epais)), bord)
	br, _, _ := pCreateSolidBrush.Call(fond)
	vp, _, _ := pSelectObject.Call(dc, pen)
	vb, _, _ := pSelectObject.Call(dc, br)
	pRoundRect.Call(dc, uintptr(r.Left), uintptr(r.Top), uintptr(r.Right), uintptr(r.Bottom), uintptr(px(rayon)), uintptr(px(rayon)))
	pSelectObject.Call(dc, vp)
	pSelectObject.Call(dc, vb)
	pDeleteObject.Call(pen)
	pDeleteObject.Call(br)
}

func ecrire(dc uintptr, s string, r RECT, f, couleur uintptr, flags uint32) {
	pSelectObject.Call(dc, f)
	pSetTextColor.Call(dc, couleur)
	pDrawTextW.Call(dc, uintptr(unsafe.Pointer(u16(s))), ^uintptr(0), uintptr(unsafe.Pointer(&r)), uintptr(flags|dtNoPrefix))
}

func peindre(dc uintptr) {
	W, H := px(largeurClient), px(hauteurClient)
	remplir(dc, RECT{0, 0, W, H}, cFond)
	pSetBkMode.Call(dc, 1)

	// Quadrillage façon papier millimétré de la DS.
	pas := px(8)
	if pas < 4 {
		pas = 4
	}
	for x := int32(0); x < W; x += pas {
		remplir(dc, RECT{x, 0, x + 1, H}, cGrille)
	}
	for y := int32(0); y < H; y += pas {
		remplir(dc, RECT{0, y, W, y + 1}, cGrille)
	}

	// Barre du haut : nom à gauche, heure et date à droite.
	remplir(dc, RECT{0, 0, W, px(26)}, cBarre)
	remplir(dc, RECT{0, px(26), W, px(26) + 1}, cBarreBord)
	maintenant := time.Now()
	ecrire(dc, "Eris Ezio", rect(10, 0, 200, 26), fPetit, cTexte, dtVCenter|dtSingleLine)
	ecrire(dc, maintenant.Format("15:04")+"   "+maintenant.Format("02/01"), rect(largeurClient-170, 0, 160, 26),
		fPetit, cTexte, dtVCenter|dtSingleLine|0x2 /* DT_RIGHT */)

	// Cartes.
	for i, c := range cartes {
		r := rect(c.x, c.y, c.w, c.h)
		if c.active {
			arrondi(dc, RECT{r.Left - px(2), r.Top - px(2), r.Right + px(2), r.Bottom + px(2)}, cActifClair, cActifClair, 1, 12)
			arrondi(dc, r, cCarte, cActif, 2, 10)
		} else {
			arrondi(dc, r, cCarte, cCarteBord, 1, 10)
		}
		if i == 0 {
			if icone44 != 0 {
				pDrawIconEx.Call(dc, uintptr(px(c.x+12)), uintptr(px(c.y+13)), icone44, uintptr(px(44)), uintptr(px(44)), 0, 0, 3)
			}
			ecrire(dc, "Eris Ezio's Launcher", rect(c.x+68, c.y+12, c.w-80, 26), fTitre, cTexte, dtSingleLine|dtVCenter)
			ecrire(dc, "Version "+version+"  ·  "+emu.nom+"  ·  RunAsDate", rect(c.x+68, c.y+38, c.w-80, 20), fPetit, cDiscret, dtSingleLine|dtVCenter|dtEndEllipsis)
			continue
		}
		ecrire(dc, c.titre, rect(c.x+12, c.y+6, c.w-24, 18), fMini, c.couleur, dtSingleLine|dtVCenter)
		if c.texteVide != "" { // carte « fichier »
			t, coul := c.texte, cTexte
			if t == "" {
				t, coul = c.texteVide, cDiscret
			}
			ecrire(dc, t, rect(c.x+12, c.y+26, c.w-24-70, 26), fNormal, coul, dtSingleLine|dtVCenter|dtEndEllipsis)
		}
	}

	// Barre du bas : état et progression.
	yb := hauteurClient - 30
	remplir(dc, rect(0, yb, largeurClient, 30), cBarre)
	remplir(dc, RECT{0, px(yb), W, px(yb) + 1}, cBarreBord)
	verrou.Lock()
	etat, i, n := etatTexte, progI, progN
	verrou.Unlock()
	larg := largeurClient - 20
	if n > 0 && enCours {
		larg = largeurClient - 150
		arrondi(dc, rect(largeurClient-130, yb+10, 120, 10), cCarte, cCarteBord, 1, 6)
		if i > 0 {
			arrondi(dc, rect(largeurClient-130, yb+10, 120*i/n, 10), cActif, cActif, 1, 6)
		}
	}
	ecrire(dc, etat, rect(10, yb, larg, 30), fPetit, cTexte, dtSingleLine|dtVCenter|dtEndEllipsis)
}

func peindreFenetre(h uintptr) {
	var ps paintStruct
	dc, _, _ := pBeginPaint.Call(h, uintptr(unsafe.Pointer(&ps)))
	W, H := px(largeurClient), px(hauteurClient)
	mem, _, _ := pCreateCompatDC.Call(dc)
	bmp, _, _ := pCreateCompatBmp.Call(dc, uintptr(W), uintptr(H))
	ancien, _, _ := pSelectObject.Call(mem, bmp)
	peindre(mem)
	pBitBlt.Call(dc, 0, 0, uintptr(W), uintptr(H), mem, 0, 0, 0x00CC0020)
	pSelectObject.Call(mem, ancien)
	pDeleteObject.Call(bmp)
	pDeleteDC.Call(mem)
	pEndPaint.Call(h, uintptr(unsafe.Pointer(&ps)))
}

// Gros bouton « LANCER », dessiné comme une carte de la DS.
func peindreBouton(d *drawItem) {
	dc, r := d.hDC, d.rcItem
	remplir(dc, r, cFond)
	appuye := d.itemState&odsSelected != 0
	inactif := d.itemState&odsDisabled != 0
	fond, bord := cBouton, cActif
	if appuye {
		fond = cBoutonBas
	}
	if inactif {
		fond, bord = rgb(240, 240, 240), cCarteBord
	}
	pSetBkMode.Call(dc, 1)
	arrondi(dc, RECT{r.Left + px(1), r.Top + px(1), r.Right - px(1), r.Bottom - px(1)}, fond, bord, 2, 12)
	titre := "L A N C E R"
	n, _, dep := depuisChamps()
	sous := fmt.Sprintf("%d fenêtres  ·  horloges de %s à %s", n, dep.Format("15:04"),
		dep.Add(time.Duration(n-1)*time.Minute).Format("15:04"))
	couleur := cActif
	if enCours {
		titre, sous, couleur, bord = "A R R Ê T E R", "Clique pour stopper l'ouverture des fenêtres.", cRose, cRose
		if arret.Load() {
			titre, sous = "A R R Ê T  E N  C O U R S …", "Les fenêtres déjà ouvertes vont être rangées."
		}
		arrondi(dc, RECT{r.Left + px(1), r.Top + px(1), r.Right - px(1), r.Bottom - px(1)}, fond, bord, 2, 12)
	}
	if inactif {
		couleur = cDiscret
	}
	h := r.Bottom - r.Top
	ecrire(dc, titre, RECT{r.Left, r.Top + h/8, r.Right, r.Top + h*5/8}, fGros, couleur, dtCenter|dtVCenter|dtSingleLine)
	ecrire(dc, sous, RECT{r.Left, r.Top + h*9/16, r.Right, r.Bottom - h/10}, fPetit, cDiscret, dtCenter|dtVCenter|dtSingleLine)
}

// ---------- fichiers, champs et réglages ----------

func filtreRom() string {
	switch variante {
	case "melonds":
		return "ROM Nintendo DS\x00*.nds;*.srl;*.dsi;*.zip;*.7z\x00Tous les fichiers\x00*.*\x00\x00"
	case "azahar":
		return "ROM Nintendo 3DS\x00*.3ds;*.cci;*.cxi;*.cia;*.3dsx;*.app;*.elf\x00Tous les fichiers\x00*.*\x00\x00"
	}
	return "ROM Game Boy\x00*.gba;*.gbc;*.gb;*.zip;*.7z\x00Tous les fichiers\x00*.*\x00\x00"
}

func ouvrirFichier(titre, filtre string) string {
	buf := make([]uint16, 1024)
	f, _ := syscall.UTF16FromString(filtre)
	ofn := openFileName{
		hwndOwner:   hwndMain,
		lpstrFilter: &f[0],
		lpstrFile:   &buf[0],
		nMaxFile:    uint32(len(buf)),
		lpstrTitle:  u16(titre),
		Flags:       0x00001000 | 0x00000800 | 0x00080000,
	}
	ofn.lStructSize = uint32(unsafe.Sizeof(ofn))
	if r, _, _ := pGetOpenFileNameW.Call(uintptr(unsafe.Pointer(&ofn))); r == 0 {
		return ""
	}
	return syscall.UTF16ToString(buf)
}

func lireDTP(h uintptr) systemTime {
	var st systemTime
	envoyer(h, dtmGetSystemTim, 0, uintptr(unsafe.Pointer(&st)))
	return st
}

func ecrireDTP(h uintptr, t time.Time) {
	st := systemTime{Year: uint16(t.Year()), Month: uint16(t.Month()), Day: uint16(t.Day()),
		Hour: uint16(t.Hour()), Minute: uint16(t.Minute()), Second: uint16(t.Second())}
	envoyer(h, dtmSetSystemTim, 0, uintptr(unsafe.Pointer(&st)))
}

func nombre(h uintptr, def int) int {
	v, err := strconv.Atoi(strings.TrimSpace(texteDe(h)))
	if err != nil || v < 1 {
		return def
	}
	if v > maxFenetres {
		return maxFenetres
	}
	return v
}

func depuisChamps() (n, l int, depart time.Time) {
	n = nombre(edN, 20)
	l = nombre(edL, 5)
	d, h := lireDTP(dtDate), lireDTP(dtHeure)
	if d.Year == 0 {
		return n, l, time.Now()
	}
	depart = time.Date(int(d.Year), time.Month(d.Month), int(d.Day), int(h.Hour), int(h.Minute), int(h.Second), 0, time.UTC)
	return
}

func chargerChamps() {
	ini := lireIni()
	n, l := 20, 5
	if v, err := strconv.Atoi(ini["fenetres"]); err == nil && v >= 1 && v <= maxFenetres {
		n = v
	}
	if v, err := strconv.Atoi(ini["parLigne"]); err == nil && v >= 1 && v <= maxFenetres {
		l = v
	}
	envoyer(udN, udmSetPos32, 0, uintptr(n))
	envoyer(udL, udmSetPos32, 0, uintptr(l))

	t := time.Now()
	var j, m, a, hh, mm, ss int
	if _, err := fmt.Sscanf(ini["date"], "%d/%d/%d", &j, &m, &a); err == nil {
		t = time.Date(a, time.Month(m), j, t.Hour(), t.Minute(), 0, 0, time.Local)
	}
	if c, _ := fmt.Sscanf(ini["heure"], "%d:%d:%d", &hh, &mm, &ss); c >= 2 {
		t = time.Date(t.Year(), t.Month(), t.Day(), hh, mm, ss, 0, time.Local)
	}
	ecrireDTP(dtDate, t)
	ecrireDTP(dtHeure, t)

	coche := uintptr(0)
	switch ini["decalage"] {
	case "1":
		coche = 1
	case "":
		if variante == "melonds" { // réglage historique de melonDS
			coche = 1
		}
	}
	envoyer(ckDecal, 0x00F1, coche, 0) // BM_SETCHECK

	cheminRom, cheminGba, cheminSav = ini["rom"], ini["romGBA"], ""
	if cheminRom != "" && !existe(cheminRom) {
		cheminRom = ""
	}
	if cheminGba != "" && !existe(cheminGba) {
		cheminGba = ""
	}
}

func sauverChamps() map[string]string {
	ini := lireIni()
	n, l, dep := depuisChamps()
	ini["fenetres"] = strconv.Itoa(n)
	ini["parLigne"] = strconv.Itoa(l)
	ini["date"] = dep.Format("02/01/2006")
	ini["heure"] = dep.Format("15:04:05")
	ini["rom"] = cheminRom
	ini["decalage"] = "0"
	if decalageCoche() {
		ini["decalage"] = "1"
	}
	if variante == "melonds" {
		ini["romGBA"] = cheminGba
	}
	ecrireIni(ini)
	return ini
}

func decalageCoche() bool { return envoyer(ckDecal, 0x00F0, 0, 0) == 1 } // BM_GETCHECK

func changerEmulateur(k string) {
	variante = k
	emu = profils[k]
	_ = os.WriteFile(cheminChoix(), []byte("dernier="+k+"\r\n"), 0644)
	chargerChamps()
	definirEtat("Prêt — glisse une ROM ou une sauvegarde sur la fenêtre.")
	disposer()
}

func fichierChoisi() {
	sauverChamps()
	disposer()
}

func fichierDepose(p string) {
	if strings.HasSuffix(strings.ToLower(p), ".lnk") {
		p = resoudreRaccourci(p)
	}
	if !existe(p) || enCours {
		return
	}
	ext := strings.ToLower(filepath.Ext(p))
	switch {
	case estSauvegarde(p):
		if variante == "azahar" {
			definirEtat("Azahar gère ses sauvegardes lui-même : sauvegarde ignorée.")
			return
		}
		cheminSav = p
		definirEtat("Sauvegarde prête : elle sera installée au prochain lancement.")
	case variante == "melonds" && (ext == ".gba" || ext == ".gb" || ext == ".gbc"):
		cheminGba = p
		definirEtat("Cartouche GBA insérée.")
	default:
		cheminRom = p
		definirEtat("ROM chargée.")
	}
	fichierChoisi()
}

// ---------- lancement ----------

func activer(oui bool) {
	for _, h := range []uintptr{cbEmu, edN, udN, edL, udL, dtDate, dtHeure, ckDecal, btRom, btRomX, btGba, btGbaX, btSav, btSavX} {
		pEnableWindow.Call(h, boolPtr(oui))
	}
	if oui && variante == "azahar" {
		pEnableWindow.Call(btSav, 0)
		pEnableWindow.Call(btSavX, 0)
	}
}

func lancer() {
	if enCours { // le bouton sert alors à arrêter
		if !arret.Load() {
			arret.Store(true)
			definirEtat("Arrêt demandé — la fenêtre en cours se termine…")
			pInvalidateRect.Call(btLancer, 0, 0)
		}
		return
	}
	arret.Store(false)
	ini := sauverChamps()
	runAsDate := trouverRunAsDate(ini)
	if runAsDate == "" {
		boite("RunAsDate introuvable", "Indique où se trouve RunAsDate.exe pour pouvoir lancer les fenêtres.", 0x30)
		return
	}
	exeEmu := trouverEmulateur(ini)
	if exeEmu == "" {
		boite(emu.nom+" introuvable", "Indique où se trouve l'exécutable de "+emu.nom+".", 0x30)
		return
	}
	ini["RunAsDate"] = runAsDate
	ini[emu.cleIni] = exeEmu

	// Sauvegarde déposée : installée pour cette ROM (l'ancienne est mise de côté).
	if cheminSav != "" && variante != "azahar" {
		copie, err := installerSauvegarde(cheminSav, cheminRom)
		if err != nil {
			boite("Sauvegarde", err.Error(), 0x30)
			return
		}
		msg := "Sauvegarde installée : " + filepath.Base(cibleSauvegarde(cheminRom))
		if copie != "" {
			msg += " (ancienne gardée en " + filepath.Base(copie) + ")"
		}
		definirEtat(msg)
		cheminSav = "" // usage unique, pour ne jamais réécraser la progression
	}

	emu.decalage = decalageCoche()

	var s session
	reglagesAvances(ini, &s)
	ecrireIni(ini)
	s.runAsDate, s.emulateur = runAsDate, exeEmu
	s.n, s.parLigne, s.depart = depuisChamps()
	s.rom = cheminRom
	if variante == "melonds" && cheminRom != "" {
		s.romGBA = cheminGba
	}

	enCours = true
	activer(false)
	disposer()
	go func() {
		err := lancerSession(s, definirEtat, func(i, n int) {
			verrou.Lock()
			progI, progN = i, n
			verrou.Unlock()
			redessiner()
		})
		erreurSession = ""
		if err != nil {
			erreurSession = err.Error()
		}
		pPostMessageW.Call(hwndMain, msgFini, 0, 0)
	}()
}

// ---------- procédure de fenêtre ----------

var procFenetre = syscall.NewCallback(func(h, m, w, l uintptr) uintptr {
	switch uint32(m) {
	case wmEraseBkgnd:
		return 1
	case 0x02E0: // WM_DPICHANGED : la fenêtre change d'écran / d'échelle
		if d := int(w & 0xFFFF); d > 0 {
			echelle = float64(d) / 96
		}
		r := (*RECT)(unsafe.Pointer(l))
		pSetWindowPos.Call(h, 0, uintptr(r.Left), uintptr(r.Top), uintptr(r.Right-r.Left), uintptr(r.Bottom-r.Top),
			swpNoZOrderFlag|swpNoActivate)
		appliquerEchelle()
		disposer()
		pInvalidateRect.Call(h, 0, 1)
		return 0
	case wmPaint:
		peindreFenetre(h)
		return 0
	case wmTimer:
		redessiner()
		pInvalidateRect.Call(btLancer, 0, 0)
		return 0
	case wmDrawItem:
		peindreBouton((*drawItem)(unsafe.Pointer(l)))
		return 1
	case wmCtlColorStat, wmCtlColorEdit:
		pSetTextColor.Call(w, cTexte)
		pSetBkColor.Call(w, cCarte)
		return brosseCarte
	case wmCommand:
		id, code := int(w&0xFFFF), int((w>>16)&0xFFFF)
		if code == 0x0300 { // EN_CHANGE : met à jour le résumé du bouton
			pInvalidateRect.Call(btLancer, 0, 0)
		}
		switch {
		case id == idCombo && code == cbnSelChange:
			i := envoyer(cbEmu, cbGetCurSel, 0, 0)
			if int(i) >= 0 && int(i) < len(ordreProfils) {
				sauverChamps()
				changerEmulateur(ordreProfils[i])
			}
		case id == idLancer && code == bnClicked:
			lancer()
		case id == idRom && code == bnClicked:
			if p := ouvrirFichier("Choisir la ROM", filtreRom()); p != "" {
				cheminRom = p
				fichierChoisi()
			}
		case id == idRomX && code == bnClicked:
			cheminRom = ""
			fichierChoisi()
		case id == idGba && code == bnClicked:
			if p := ouvrirFichier("Choisir la cartouche GBA à insérer", "ROM Game Boy Advance\x00*.gba\x00Tous les fichiers\x00*.*\x00\x00"); p != "" {
				cheminGba = p
				fichierChoisi()
			}
		case id == idGbaX && code == bnClicked:
			cheminGba = ""
			fichierChoisi()
		case id == idSav && code == bnClicked:
			if p := ouvrirFichier("Choisir la sauvegarde", "Sauvegardes\x00*.sav;*.dsv;*.srm\x00Tous les fichiers\x00*.*\x00\x00"); p != "" {
				cheminSav = p
				definirEtat("Sauvegarde prête : elle sera installée au prochain lancement.")
				fichierChoisi()
			}
		case id == idSavX && code == bnClicked:
			cheminSav = ""
			fichierChoisi()
		}
		return 0
	case wmDropFiles:
		n, _, _ := pDragQueryFileW.Call(w, 0xFFFFFFFF, 0, 0)
		for i := uintptr(0); i < n && i < 3; i++ {
			buf := make([]uint16, 1024)
			pDragQueryFileW.Call(w, i, uintptr(unsafe.Pointer(&buf[0])), uintptr(len(buf)))
			fichierDepose(syscall.UTF16ToString(buf))
		}
		pDragFinish.Call(w)
		return 0
	case msgFini:
		enCours = false
		arret.Store(false)
		activer(true)
		pInvalidateRect.Call(btLancer, 0, 0)
		disposer()
		if erreurSession != "" {
			definirEtat("Lancement interrompu.")
			boite("Lancement interrompu", erreurSession, 0x10)
		}
		return 0
	case wmDestroy:
		pPostQuitMessage.Call(0)
		return 0
	}
	r, _, _ := pDefWindowProcW.Call(h, m, w, l)
	return r
})

var brosseCarte uintptr

// Demande d'arrêt de l'ouverture des fenêtres (bouton ARRÊTER).
var arret atomic.Bool

// ---------- démarrage ----------

func main() {
	if pSetProcessDpiAwarenessContext.Find() == nil {
		pSetProcessDpiAwarenessContext.Call(dpiAwarenessPerMonitorV2)
	} else {
		pSetProcessDPIAware.Call()
	}
	icc := [2]uint32{8, 0x0000FFFF}
	pInitCommonCtrlsEx.Call(uintptr(unsafe.Pointer(&icc[0])))
	hInst, _, _ = pGetModuleHandleW.Call(0)
	if pGetDpiForSystem.Find() == nil {
		if d, _, _ := pGetDpiForSystem.Call(); d > 0 {
			echelle = float64(d) / 96
		}
	}

	variante = "melonds"
	if data, err := os.ReadFile(cheminChoix()); err == nil {
		v := strings.TrimSpace(strings.TrimPrefix(strings.TrimSpace(string(data)), "dernier="))
		if _, ok := profils[v]; ok {
			variante = v
		}
	}
	emu = profils[variante]

	demanderFichier = func(nom string) string {
		p := ouvrirFichier("Où se trouve "+nom+" ?", "Programmes\x00*.exe;*.lnk\x00Tous les fichiers\x00*.*\x00\x00")
		if strings.HasSuffix(strings.ToLower(p), ".lnk") {
			p = resoudreRaccourci(p)
		}
		if !existe(p) {
			return ""
		}
		return p
	}

	brosseCarte, _, _ = pCreateSolidBrush.Call(cCarte)
	iconeGrande, _, _ := pLoadImageW.Call(hInst, resIcone, 1, 0, 0, 0x40)
	curseur, _, _ := pLoadCursorW.Call(0, 32512)
	classe := u16("ErisEzioLauncher")
	wc := wndClassEx{lpfnWndProc: procFenetre, hInstance: hInst, hIcon: iconeGrande, hIconSm: iconeGrande,
		hCursor: curseur, lpszClassName: classe}
	wc.cbSize = uint32(unsafe.Sizeof(wc))
	pRegisterClassExW.Call(uintptr(unsafe.Pointer(&wc)))

	sx, _, _ := pGetSystemMetrics.Call(0)
	sy, _, _ := pGetSystemMetrics.Call(1)
	hwndMain, _, _ = pCreateWindowExW.Call(wsExAccept, uintptr(unsafe.Pointer(classe)),
		uintptr(unsafe.Pointer(u16("Eris Ezio's Launcher"))),
		wsCaption|wsSysMenu|wsMinimizeBox|wsClipChildren,
		uintptr(int32(sx)/2-px(largeurClient)/2), uintptr(int32(sy)/2-px(380)),
		uintptr(px(largeurClient)), uintptr(px(700)), 0, 0, hInst, 0)
	pDragAcceptFiles.Call(hwndMain, 1)
	if pGetDpiForWindow.Find() == nil {
		if d, _, _ := pGetDpiForWindow.Call(hwndMain); d > 0 {
			echelle = float64(d) / 96
		}
	}
	appliquerEchelle()

	cbEmu = controle("COMBOBOX", "", cbsDropList|wsTabStop|wsVScroll, 0, idCombo, fNormal)
	for i, k := range ordreProfils {
		envoyer(cbEmu, cbAddString, 0, uintptr(unsafe.Pointer(u16(profils[k].nom))))
		if k == variante {
			envoyer(cbEmu, cbSetCurSel, uintptr(i), 0)
		}
	}
	edN = controle("EDIT", "20", esNumber|esAutoHScroll|wsTabStop, wsExClient, 0, fNormal)
	udN = controle("msctls_updown32", "", udsBuddyInt|udsRight|udsArrows|udsNoThousands, 0, 0, 0)
	envoyer(udN, udmSetRange32, 1, maxFenetres)
	edL = controle("EDIT", "5", esNumber|esAutoHScroll|wsTabStop, wsExClient, 0, fNormal)
	udL = controle("msctls_updown32", "", udsBuddyInt|udsRight|udsArrows|udsNoThousands, 0, 0, 0)
	envoyer(udL, udmSetRange32, 1, maxFenetres)
	dtDate = controle("SysDateTimePick32", "", wsTabStop, 0, 0, fNormal)
	envoyer(dtDate, dtmSetFormatW, 0, uintptr(unsafe.Pointer(u16("dd/MM/yyyy"))))
	dtHeure = controle("SysDateTimePick32", "", dtsTimeFormat|wsTabStop, 0, 0, fNormal)
	envoyer(dtHeure, dtmSetFormatW, 0, uintptr(unsafe.Pointer(u16("HH':'mm':'ss"))))
	btRom = controle("BUTTON", "…", wsTabStop, 0, idRom, fNormal)
	btRomX = controle("BUTTON", "×", wsTabStop, 0, idRomX, fNormal)
	btGba = controle("BUTTON", "…", wsTabStop, 0, idGba, fNormal)
	btGbaX = controle("BUTTON", "×", wsTabStop, 0, idGbaX, fNormal)
	btSav = controle("BUTTON", "…", wsTabStop, 0, idSav, fNormal)
	btSavX = controle("BUTTON", "×", wsTabStop, 0, idSavX, fNormal)
	ckDecal = controle("BUTTON", "Décaler les lignes 2, 4… d'une demi-fenêtre", 0x0003|wsTabStop, 0, 0, fNormal) // BS_AUTOCHECKBOX
	btLancer = controle("BUTTON", "Lancer", bsOwnerDraw|wsTabStop, 0, idLancer, fGros)

	chargerChamps()
	disposer()
	pSetTimer.Call(hwndMain, 1, 1000, 0) // horloge de la barre du haut
	pShowWindow.Call(hwndMain, 5)

	var m msgW
	for {
		r, _, _ := pGetMessageW.Call(uintptr(unsafe.Pointer(&m)), 0, 0, 0)
		if int32(r) <= 0 {
			break
		}
		if d, _, _ := pIsDialogMessageW.Call(hwndMain, uintptr(unsafe.Pointer(&m))); d != 0 {
			continue
		}
		pTranslateMessage.Call(uintptr(unsafe.Pointer(&m)))
		pDispatchMessageW.Call(uintptr(unsafe.Pointer(&m)))
	}
}
