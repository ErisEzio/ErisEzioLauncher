package main

import (
	"fmt"
	"os"
	"path/filepath"
	"runtime/debug"
	"sync"
	"time"
)

// Journal de diagnostic : ErisEzioLauncher.log, à côté de l'exe.
var verrouJournal sync.Mutex

func cheminJournal() string {
	exe, err := os.Executable()
	if err != nil {
		return "ErisEzioLauncher.log"
	}
	return filepath.Join(filepath.Dir(exe), "ErisEzioLauncher.log")
}

func journal(format string, a ...any) {
	verrouJournal.Lock()
	defer verrouJournal.Unlock()
	p := cheminJournal()
	if st, err := os.Stat(p); err == nil && st.Size() > 1<<20 { // au-delà de 1 Mo, on repart à zéro
		_ = os.Rename(p, p+".ancien")
	}
	f, err := os.OpenFile(p, os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0644)
	if err != nil {
		return
	}
	defer f.Close()
	fmt.Fprintf(f, "%s  %s\r\n", time.Now().Format("2006-01-02 15:04:05"), fmt.Sprintf(format, a...))
}

// À placer en defer : transforme un plantage en message + trace dans le journal.
func intercepter(ou string, apres func(msg string)) {
	if r := recover(); r != nil {
		msg := fmt.Sprintf("Erreur interne (%s) : %v", ou, r)
		journal("%s\r\n%s", msg, debug.Stack())
		if apres != nil {
			apres(msg)
		}
	}
}
