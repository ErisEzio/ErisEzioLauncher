package main

import (
	"errors"
	"fmt"
	"os/exec"
	"path/filepath"
	"strconv"
	"strings"
	"syscall"
	"time"
)

// Paramètres d'une session de lancement.
type session struct {
	runAsDate, emulateur string
	n, parLigne          int
	depart               time.Time
	rom, romGBA          string
	tailleW, tailleH     int32
	pasForce             int32
	ecran                string // nom système de l'écran choisi ("" = le plus grand)
}

// Prépare la session à partir du .ini de l'émulateur courant (réglages avancés).
func reglagesAvances(ini map[string]string, s *session) {
	if _, ok := ini["pasVertical"]; !ok {
		ini["pasVertical"] = "0"
	}
	if _, ok := ini["retoucheBordures"]; !ok {
		ini["retoucheBordures"] = "0"
	}
	if _, ok := ini["delaiLancement"]; !ok {
		ini["delaiLancement"] = "2"
	}
	retoucheBordures = ini["retoucheBordures"] == "1"
	delaiLancement = 2 * time.Second
	if v, err := strconv.ParseFloat(strings.ReplaceAll(ini["delaiLancement"], ",", "."), 64); err == nil && v >= 0 && v <= 60 {
		delaiLancement = time.Duration(v * float64(time.Second))
	}
	s.tailleW, s.tailleH = emu.clientW, emu.clientH
	if emu.clientW > 0 {
		if _, ok := ini["tailleFenetre"]; !ok {
			ini["tailleFenetre"] = fmt.Sprintf("%dx%d", emu.clientW, emu.clientH)
		}
		var a, b int32
		if _, err := fmt.Sscanf(strings.ToLower(ini["tailleFenetre"]), "%dx%d", &a, &b); err == nil && a > 0 && b > 0 {
			s.tailleW, s.tailleH = a, b
		}
	}
	p, _ := strconv.Atoi(ini["pasVertical"])
	s.pasForce = int32(p)
}

// Lance les fenêtres et les range. etat() reçoit les messages, avance(i, n) la progression.
func lancerSession(s session, etat func(string), avance func(int, int)) error {
	nomMelon = filepath.Base(s.emulateur)
	ecran := choisirEcran(s.ecran)
	zone := ecran.RcWork

	connues := map[uintptr]bool{}
	for _, h := range fenetresMelon() {
		connues[h] = true // on ne touche pas aux émulateurs déjà ouverts
	}

	fen := make([]uintptr, s.n)
	var g grille
	grillePrete := false
	dossier := filepath.Dir(s.emulateur)

	ouvertes := 0
	for i := 0; i < s.n; i++ {
		if arret.Load() {
			break
		}
		t := s.depart.Add(time.Duration(i) * time.Minute)
		etat(fmt.Sprintf("Fenêtre %d / %d  —  %s %s", i+1, s.n, t.Format("02/01/2006"), t.Format("15:04:05")))
		avance(i, s.n)

		args := []string{"/movetime", t.Format(`02\01\2006`), t.Format("15:04:05"), s.emulateur}
		if s.rom != "" {
			if s.romGBA != "" && emu.gbaArg != "" {
				args = append(args, emu.gbaArg+s.romGBA)
			}
			args = append(args, s.rom)
			if s.romGBA != "" && emu.gbaArg == "" {
				args = append(args, s.romGBA)
			}
		}
		journal("Fenêtre %d/%d : RunAsDate %q", i+1, s.n, args)
		cmd := exec.Command(s.runAsDate, args...)
		cmd.Dir = dossier
		if err := cmd.Start(); err != nil {
			var en syscall.Errno
			if errors.As(err, &en) && en == errorElevationRequired {
				return errors.New("RunAsDate demande les droits administrateur : lance le lanceur avec un clic droit > « Exécuter en tant qu'administrateur ».")
			}
			return errors.New("Impossible de lancer RunAsDate : " + err.Error())
		}
		go cmd.Wait()

		h := attendreNouvelleFenetre(connues)
		if h == 0 {
			journal("Fenêtre %d/%d : aucune fenêtre %s détectée en 30 s", i+1, s.n, nomMelon)
			continue
		}
		journal("Fenêtre %d/%d : détectée", i+1, s.n)
		connues[h] = true
		fen[i] = h
		ouvertes++
		time.Sleep(700 * time.Millisecond) // laisse l'émulateur finir d'afficher sa fenêtre
		redimensionner(h, s.tailleW, s.tailleH)

		if !grillePrete {
			r := rectVisible(h)
			w0, h0 := r.Right-r.Left, r.Bottom-r.Top
			if w0 < 50 || h0 < 50 {
				w0, h0 = 512, 880
			}
			g = calculerGrille(s.n, s.parLigne, w0, h0, zone, s.pasForce)
			grillePrete = true
		}
		x, y := g.position(i)
		placer(h, x, y)
		if i < s.n-1 {
			for fin := time.Now().Add(delaiLancement); time.Now().Before(fin) && !arret.Load(); {
				time.Sleep(100 * time.Millisecond)
			}
		}
	}
	avance(s.n, s.n)

	if !grillePrete {
		if arret.Load() {
			etat("Arrêté : aucune fenêtre n'a été ouverte.")
			return nil
		}
		return errors.New("Aucune fenêtre " + emu.nom + " n'a été détectée.")
	}

	// Dernière passe : tout remettre en place et coller les zones d'affichage.
	etat("Rangement final…")
	time.Sleep(1500 * time.Millisecond)
	ok := 0
	for i, h := range fen {
		if h == 0 {
			continue
		}
		if v, _, _ := pIsWindow.Call(h); v == 0 {
			continue
		}
		redimensionner(h, s.tailleW, s.tailleH)
		x, y := g.position(i)
		placer(h, x, y)
		if col := i % g.cols; col > 0 && fen[i-1] != 0 {
			if v, _, _ := pIsWindow.Call(fen[i-1]); v != 0 {
				if dx := rectClient(fen[i-1]).Right - rectClient(h).Left; dx != 0 {
					placer(h, rectVisible(h).Left+dx, y)
				}
			}
		}
		ok++
	}
	lignes := (s.n + g.cols - 1) / g.cols
	fin := s.depart.Add(time.Duration(s.n-1) * time.Minute)
	if arret.Load() {
		etat(fmt.Sprintf("Arrêté : %d fenêtre(s) ouverte(s) sur %d, rangées à leur place.", ouvertes, s.n))
		return nil
	}
	etat(fmt.Sprintf("Terminé : %d / %d fenêtres en %d ligne(s) de %d.\nHorloges de %s à %s.",
		ok, s.n, lignes, g.cols, s.depart.Format("15:04"), fin.Format("15:04")))
	return nil
}
