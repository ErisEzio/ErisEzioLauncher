// Lanceur melonDS / VisualBoyAdvance : ouvre N fenêtres d'émulateur via RunAsDate (+1 minute par fenêtre)
// et les range collées les unes aux autres sur le plus grand écran (l'écran 4K).
package main

import (
	"bufio"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"strings"
	"syscall"
	"time"
	"unsafe"
)

var (
	user32   = syscall.NewLazyDLL("user32.dll")
	kernel32 = syscall.NewLazyDLL("kernel32.dll")
	dwmapi   = syscall.NewLazyDLL("dwmapi.dll")
	shell32  = syscall.NewLazyDLL("shell32.dll")

	pEnumWindows                   = user32.NewProc("EnumWindows")
	pIsWindowVisible               = user32.NewProc("IsWindowVisible")
	pIsWindow                      = user32.NewProc("IsWindow")
	pGetWindow                     = user32.NewProc("GetWindow")
	pGetWindowTextLengthW          = user32.NewProc("GetWindowTextLengthW")
	pGetWindowThreadProcessId      = user32.NewProc("GetWindowThreadProcessId")
	pGetWindowRect                 = user32.NewProc("GetWindowRect")
	pSetWindowPos                  = user32.NewProc("SetWindowPos")
	pGetClientRect                 = user32.NewProc("GetClientRect")
	pClientToScreen                = user32.NewProc("ClientToScreen")
	pShowWindow                    = user32.NewProc("ShowWindow")
	pIsZoomed                      = user32.NewProc("IsZoomed")
	pIsIconic                      = user32.NewProc("IsIconic")
	pEnumDisplayMonitors           = user32.NewProc("EnumDisplayMonitors")
	pGetMonitorInfoW               = user32.NewProc("GetMonitorInfoW")
	pSetProcessDpiAwarenessContext = user32.NewProc("SetProcessDpiAwarenessContext")
	pSetProcessDPIAware            = user32.NewProc("SetProcessDPIAware")
	pOpenProcess                   = kernel32.NewProc("OpenProcess")
	pQueryFullProcessImageNameW    = kernel32.NewProc("QueryFullProcessImageNameW")
	pCloseHandle                   = kernel32.NewProc("CloseHandle")
	pSetConsoleTitleW              = kernel32.NewProc("SetConsoleTitleW")
	pDwmGetWindowAttribute         = dwmapi.NewProc("DwmGetWindowAttribute")
	pDwmSetWindowAttribute         = dwmapi.NewProc("DwmSetWindowAttribute")
	pSHGetFolderPathW              = shell32.NewProc("SHGetFolderPathW")
)

type RECT struct{ Left, Top, Right, Bottom int32 }

type MONITORINFO struct {
	CbSize    uint32
	RcMonitor RECT
	RcWork    RECT
	DwFlags   uint32
	SzDevice  [32]uint16
}

// Nom système d'un écran (ex. \\.\DISPLAY1).
func (m MONITORINFO) nomEcran() string { return syscall.UTF16ToString(m.SzDevice[:]) }

// Liste des écrans, de gauche à droite.
func listerEcrans() []MONITORINFO {
	ecrans = nil
	pEnumDisplayMonitors.Call(0, 0, monCbProc, 0)
	l := append([]MONITORINFO(nil), ecrans...)
	for i := 1; i < len(l); i++ {
		for j := i; j > 0 && (l[j].RcMonitor.Left < l[j-1].RcMonitor.Left ||
			(l[j].RcMonitor.Left == l[j-1].RcMonitor.Left && l[j].RcMonitor.Top < l[j-1].RcMonitor.Top)); j-- {
			l[j], l[j-1] = l[j-1], l[j]
		}
	}
	return l
}

const (
	gwOwner                  = 4
	swRestore                = 9
	swpNoSize                = 0x0001
	swpNoMove                = 0x0002
	swpNoZOrderFlag          = 0x0004
	hwndTop                  = 0
	swpNoActivate            = 0x0010
	dwmwaExtendedFrameBounds = 9
	dwmwaCornerPreference    = 33
	dwmwaBorderColor         = 34
	dwmwcpDoNotRound         = 1
	dwmwaColorNone           = 0xFFFFFFFE
	processQueryLimitedInfo  = 0x1000
	csidlDesktopDirectory    = 0x10
	errorElevationRequired   = 740
	maxFenetres              = 60
	delaiDetectionFenetre    = 30 * time.Second
	dpiAwarenessPerMonitorV2 = ^uintptr(3) // (HANDLE)-4
)

var in = bufio.NewReader(os.Stdin)

// Version du lanceur : X.Y.Z (X = version, Y = ajout majeur, Z = révision).
var version = "1.2.0"

// Émulateur choisi au démarrage (menu).
var variante = ""

type profilEmu struct {
	nom        string   // nom affiché
	cleIni     string   // clé du chemin dans le .ini
	ini        string   // fichier de réglages
	exes       []string // noms d'exe recherchés (motifs * acceptés)
	raccourcis []string // motifs de raccourcis sur le bureau
	rapportPas float64  // décalage vertical entre lignes / hauteur d'une fenêtre
	clientW    int32    // taille imposée de la zone d'affichage (0 = taille d'origine)
	clientH    int32
	decalage   bool   // lignes paires décalées d'une demi-fenêtre
	gba        bool   // emplacement GBA (cartouche GBA insérée)
	gbaArg     string // préfixe de l'option GBA ("" = 2e fichier après la ROM)
	sauvegarde string // "rom" (.sav à côté de la ROM), "desmume" (Battery\*.dsv), "" (non géré)
}

var profils = map[string]profilEmu{
	"melonds": {nom: "melonDS", cleIni: "melonDS", ini: "LanceurMelonDS.ini",
		exes: []string{"melonDS.exe"}, raccourcis: []string{"melonDS*.lnk"},
		rapportPas: 0.577, decalage: true, gba: true, sauvegarde: "rom"},
	"desmume": {nom: "DeSmuME", cleIni: "DeSmuME", ini: "LanceurDeSmuME.ini",
		exes: []string{"DeSmuME.exe", "DeSmuME*.exe", "desmume*.exe"}, raccourcis: []string{"DeSmuME*.lnk", "desmume*.lnk"},
		rapportPas: 0.577, gba: true, gbaArg: "--gbaslot-rom=", sauvegarde: "desmume"},
	"vba": {nom: "VisualBoyAdvance", cleIni: "VisualBoyAdvance", ini: "LanceurVBA.ini",
		exes:       []string{"visualboyadvance-m.exe", "VisualBoyAdvance-M.exe", "VisualBoyAdvance.exe", "vbam.exe", "VBA.exe"},
		raccourcis: []string{"VisualBoyAdvance*.lnk", "visualboyadvance*.lnk", "VBA*.lnk"},
		rapportPas: 1.0, sauvegarde: "rom"},
	// mGBA : zone d'affichage 320 x 326 = barre de menus (38 px) + jeu en x2 (320 x 288), mesurée sur la fenêtre modèle.
	"mgba": {nom: "mGBA", cleIni: "mGBA", ini: "LanceurMGBA.ini",
		exes: []string{"mGBA.exe"}, raccourcis: []string{"mGBA*.lnk"},
		rapportPas: 1.0, clientW: 320, clientH: 326, sauvegarde: "rom"},
	"azahar": {nom: "Azahar", cleIni: "Azahar", ini: "LanceurAzahar.ini",
		exes: []string{"azahar.exe", "azahar-qt.exe"}, raccourcis: []string{"Azahar*.lnk"},
		rapportPas: 0.577},
}

var ordreProfils = []string{"melonds", "desmume", "vba", "mgba", "azahar"}

func cheminChoix() string {
	exe, err := os.Executable()
	if err != nil {
		return "ErisEzioLanceur.ini"
	}
	return filepath.Join(filepath.Dir(exe), "ErisEzioLanceur.ini")
}

// Menu de choix de l'émulateur ; le dernier choix est proposé par défaut.
func choisirEmulateur() string {
	def := 1
	if data, err := os.ReadFile(cheminChoix()); err == nil {
		v := strings.TrimSpace(strings.TrimPrefix(strings.TrimSpace(string(data)), "dernier="))
		for i, k := range ordreProfils {
			if k == v {
				def = i + 1
			}
		}
	}
	fmt.Println("Quel émulateur lancer ?")
	for i, k := range ordreProfils {
		fmt.Printf("  %d - %s\n", i+1, profils[k].nom)
	}
	for {
		fmt.Printf("Ton choix [%d] : ", def)
		s := lireLigne()
		n := def
		if s != "" {
			v, err := strconv.Atoi(s)
			if err != nil || v < 1 || v > len(ordreProfils) {
				fmt.Printf("  -> Entre un nombre entre 1 et %d.\n", len(ordreProfils))
				continue
			}
			n = v
		}
		k := ordreProfils[n-1]
		_ = os.WriteFile(cheminChoix(), []byte("dernier="+k+"\r\n"), 0644)
		return k
	}
}

var emu = profils["melonds"]

// Réglages de stabilité (modifiables dans le .ini) :
// retoucheBordures=1 réactive la suppression du liseré gris / coins arrondis de Windows 11.
// delaiLancement = secondes d'attente entre deux fenêtres.
var (
	retoucheBordures = false
	delaiLancement   = 2 * time.Second
)

// ---------- Entrées / sorties console ----------

func lireLigne() string {
	s, _ := in.ReadString('\n')
	return strings.TrimSpace(s)
}

func nettoyerChemin(s string) string {
	s = strings.TrimSpace(s)
	s = strings.Trim(s, "\"")
	return strings.TrimSpace(s)
}

func pause() {
	fmt.Print("\nAppuie sur Entrée pour fermer...")
	lireLigne()
}

func quitter(msg string) {
	fmt.Println("\n[ERREUR] " + msg)
	pause()
	os.Exit(1)
}

// ---------- Fichier de réglages ----------

func cheminIni() string {
	exe, err := os.Executable()
	if err != nil {
		return emu.ini
	}
	return filepath.Join(filepath.Dir(exe), emu.ini)
}

func lireIni() map[string]string {
	m := map[string]string{}
	data, err := os.ReadFile(cheminIni())
	if err != nil {
		return m
	}
	for _, l := range strings.Split(string(data), "\n") {
		l = strings.TrimSpace(l)
		if i := strings.Index(l, "="); i > 0 {
			m[strings.TrimSpace(l[:i])] = strings.TrimSpace(l[i+1:])
		}
	}
	return m
}

func ecrireIni(m map[string]string) {
	var b strings.Builder
	b.WriteString("[Lanceur " + emu.nom + "]\r\n")
	for _, k := range []string{emu.cleIni, "RunAsDate", "fenetres", "parLigne", "date", "heure", "pasVertical", "tailleFenetre", "retoucheBordures", "delaiLancement", "rom", "romGBA", "decalage", "ecran"} {
		if v, ok := m[k]; ok {
			b.WriteString(k + "=" + v + "\r\n")
		}
	}
	_ = os.WriteFile(cheminIni(), []byte(b.String()), 0644)
}

// ---------- Fichiers ----------

func existe(p string) bool {
	st, err := os.Stat(p)
	return err == nil && !st.IsDir()
}

func bureau() string {
	buf := make([]uint16, 520)
	r, _, _ := pSHGetFolderPathW.Call(0, csidlDesktopDirectory, 0, 0, uintptr(unsafe.Pointer(&buf[0])))
	if r == 0 {
		return syscall.UTF16ToString(buf)
	}
	h, _ := os.UserHomeDir()
	return filepath.Join(h, "Desktop")
}

// Résout un raccourci .lnk vers le fichier cible.
func resoudreRaccourci(lnk string) string {
	script := "(New-Object -ComObject WScript.Shell).CreateShortcut('" +
		strings.ReplaceAll(lnk, "'", "''") + "').TargetPath"
	c := exec.Command("powershell", "-NoProfile", "-NonInteractive", "-Command", script)
	c.SysProcAttr = &syscall.SysProcAttr{HideWindow: true, CreationFlags: 0x08000000}
	out, err := c.Output()
	if err != nil {
		return ""
	}
	return strings.TrimSpace(string(out))
}

// Demande un fichier introuvable à l'utilisateur (fourni par l'interface).
var demanderFichier = func(nom string) string { return "" }

func trouverRunAsDate(ini map[string]string) string {
	if p := ini["RunAsDate"]; p != "" && existe(p) {
		return p
	}
	exe, _ := os.Executable()
	desk := bureau()
	for _, c := range []string{
		filepath.Join(filepath.Dir(exe), "RunAsDate.exe"),
		filepath.Join(desk, "RunAsDate.exe"),
		filepath.Join(desk, "RunAsDate", "RunAsDate.exe"),
	} {
		if existe(c) {
			return c
		}
	}
	// Raccourcis du bureau du style "RunAsDate.exe - Raccourci.lnk"
	if liens, _ := filepath.Glob(filepath.Join(desk, "RunAsDate*.lnk")); len(liens) > 0 {
		for _, l := range liens {
			if t := resoudreRaccourci(l); t != "" && existe(t) {
				return t
			}
		}
	}
	return demanderFichier("RunAsDate.exe")
}

func trouverEmulateur(ini map[string]string) string {
	if p := ini[emu.cleIni]; p != "" && existe(p) {
		return p
	}
	exe, _ := os.Executable()
	desk := bureau()
	premier := func(motif string) string {
		trouves, _ := filepath.Glob(motif)
		for _, t := range trouves {
			if existe(t) {
				return t
			}
		}
		return ""
	}
	for _, nom := range emu.exes {
		for _, d := range []string{desk, filepath.Dir(exe)} {
			if c := premier(filepath.Join(d, nom)); c != "" {
				return c
			}
		}
		// Dossiers du bureau (ex. Bureau\visualboyadvance-m\visualboyadvance-m.exe)
		if c := premier(filepath.Join(desk, "*", nom)); c != "" {
			return c
		}
	}
	for _, motif := range emu.raccourcis {
		if liens, _ := filepath.Glob(filepath.Join(desk, motif)); len(liens) > 0 {
			for _, l := range liens {
				if t := resoudreRaccourci(l); t != "" && existe(t) {
					return t
				}
			}
		}
	}
	return demanderFichier("l'exécutable de " + emu.nom)
}

// ---------- Questions ----------

func demanderNombre(defaut int) int {
	for {
		fmt.Printf("Nombre de fenêtres à ouvrir [%d] : ", defaut)
		s := lireLigne()
		if s == "" {
			return defaut
		}
		n, err := strconv.Atoi(s)
		if err == nil && n >= 1 && n <= maxFenetres {
			return n
		}
		fmt.Printf("  -> Entre un nombre entre 1 et %d.\n", maxFenetres)
	}
}

func demanderParLigne(defaut int) int {
	for {
		fmt.Printf("Fenêtres par ligne [%d] : ", defaut)
		s := lireLigne()
		if s == "" {
			return defaut
		}
		n, err := strconv.Atoi(s)
		if err == nil && n >= 1 && n <= maxFenetres {
			return n
		}
		fmt.Printf("  -> Entre un nombre entre 1 et %d.\n", maxFenetres)
	}
}

// Demande une ROM par glisser-déposer. Entrée = garder la précédente, 0 = aucune.
func demanderRom(libelle, defaut string) string {
	if defaut != "" && !existe(defaut) {
		defaut = ""
	}
	for {
		fmt.Printf("\n%s : fais glisser le fichier dans cette fenêtre, puis Entrée.\n", libelle)
		if defaut != "" {
			fmt.Printf("  (Entrée = garder « %s », 0 = aucune)\n> ", filepath.Base(defaut))
		} else {
			fmt.Print("  (Entrée ou 0 = aucune)\n> ")
		}
		p := nettoyerChemin(lireLigne())
		switch {
		case p == "":
			return defaut
		case p == "0":
			return ""
		}
		if strings.HasSuffix(strings.ToLower(p), ".lnk") {
			p = resoudreRaccourci(p)
		}
		if existe(p) {
			return p
		}
		fmt.Println("  -> Fichier introuvable, réessaie.")
	}
}

func demanderDate(defaut string) (int, int, int, string) {
	for {
		if defaut != "" {
			fmt.Printf("Date de départ (jj/mm/aaaa) [%s] : ", defaut)
		} else {
			fmt.Print("Date de départ (jj/mm/aaaa) : ")
		}
		s := lireLigne()
		if s == "" {
			s = defaut
		}
		s = strings.NewReplacer("-", "/", ".", "/", "\\", "/", " ", "").Replace(s)
		parts := strings.Split(s, "/")
		if len(parts) == 3 {
			j, e1 := strconv.Atoi(parts[0])
			m, e2 := strconv.Atoi(parts[1])
			a, e3 := strconv.Atoi(parts[2])
			if e1 == nil && e2 == nil && e3 == nil {
				if a < 100 {
					a += 2000
				}
				t := time.Date(a, time.Month(m), j, 0, 0, 0, 0, time.UTC)
				if t.Day() == j && int(t.Month()) == m && a >= 1980 && a <= 2099 {
					return j, m, a, fmt.Sprintf("%02d/%02d/%04d", j, m, a)
				}
			}
		}
		fmt.Println("  -> Date invalide. Exemple : 30/10/2026")
	}
}

func demanderHeure(defaut string) (int, int, int, string) {
	for {
		if defaut != "" {
			fmt.Printf("Heure de départ (hh:mm ou hh:mm:ss) [%s] : ", defaut)
		} else {
			fmt.Print("Heure de départ (hh:mm ou hh:mm:ss) : ")
		}
		s := lireLigne()
		if s == "" {
			s = defaut
		}
		s = strings.NewReplacer("h", ":", "H", ":", ".", ":", " ", "").Replace(s)
		s = strings.TrimSuffix(s, ":")
		parts := strings.Split(s, ":")
		vals := []int{0, 0, 0}
		ok := len(parts) >= 1 && len(parts) <= 3 && parts[0] != ""
		for i, p := range parts {
			if !ok {
				break
			}
			v, err := strconv.Atoi(p)
			if err != nil {
				ok = false
			}
			vals[i] = v
		}
		if ok && vals[0] >= 0 && vals[0] <= 23 && vals[1] >= 0 && vals[1] <= 59 && vals[2] >= 0 && vals[2] <= 59 {
			return vals[0], vals[1], vals[2], fmt.Sprintf("%02d:%02d:%02d", vals[0], vals[1], vals[2])
		}
		fmt.Println("  -> Heure invalide. Exemple : 20:19 ou 20:19:00")
	}
}

// ---------- Fenêtres ----------

var (
	nomMelon   string
	collecte   []uintptr
	enumCbProc = syscall.NewCallback(func(h, lp uintptr) uintptr {
		if v, _, _ := pIsWindowVisible.Call(h); v == 0 {
			return 1
		}
		if o, _, _ := pGetWindow.Call(h, gwOwner); o != 0 {
			return 1
		}
		if l, _, _ := pGetWindowTextLengthW.Call(h); l == 0 {
			return 1
		}
		var pid uint32
		pGetWindowThreadProcessId.Call(h, uintptr(unsafe.Pointer(&pid)))
		hp, _, _ := pOpenProcess.Call(processQueryLimitedInfo, 0, uintptr(pid))
		if hp == 0 {
			return 1
		}
		buf := make([]uint16, 1024)
		sz := uint32(len(buf))
		r, _, _ := pQueryFullProcessImageNameW.Call(hp, 0, uintptr(unsafe.Pointer(&buf[0])), uintptr(unsafe.Pointer(&sz)))
		pCloseHandle.Call(hp)
		if r == 0 {
			return 1
		}
		chemin := syscall.UTF16ToString(buf[:sz])
		if strings.EqualFold(filepath.Base(chemin), nomMelon) {
			collecte = append(collecte, h)
		}
		return 1
	})
)

func fenetresMelon() []uintptr {
	collecte = nil
	pEnumWindows.Call(enumCbProc, 0)
	return collecte
}

func attendreNouvelleFenetre(connues map[uintptr]bool) uintptr {
	fin := time.Now().Add(delaiDetectionFenetre)
	for time.Now().Before(fin) {
		for _, h := range fenetresMelon() {
			if !connues[h] {
				return h
			}
		}
		time.Sleep(150 * time.Millisecond)
	}
	return 0
}

func rectVisible(h uintptr) RECT {
	var r RECT
	res, _, _ := pDwmGetWindowAttribute.Call(h, dwmwaExtendedFrameBounds, uintptr(unsafe.Pointer(&r)), unsafe.Sizeof(r))
	if res != 0 {
		pGetWindowRect.Call(h, uintptr(unsafe.Pointer(&r)))
	}
	return r
}

// Zone d'affichage (sans cadre ni bordure) en coordonnées écran.
func rectClient(h uintptr) RECT {
	var r RECT
	pGetClientRect.Call(h, uintptr(unsafe.Pointer(&r)))
	pt := [2]int32{0, 0}
	pClientToScreen.Call(h, uintptr(unsafe.Pointer(&pt[0])))
	return RECT{pt[0], pt[1], pt[0] + r.Right, pt[1] + r.Bottom}
}

// Redimensionne la fenêtre pour que sa zone d'affichage fasse exactement w x ht.
func redimensionner(h uintptr, w, ht int32) {
	if w <= 0 || ht <= 0 {
		return
	}
	if z, _, _ := pIsZoomed.Call(h); z != 0 {
		pShowWindow.Call(h, swRestore)
	}
	for passe := 0; passe < 2; passe++ {
		var ext RECT
		pGetWindowRect.Call(h, uintptr(unsafe.Pointer(&ext)))
		c := rectClient(h)
		dw := (ext.Right - ext.Left) - (c.Right - c.Left)
		dh := (ext.Bottom - ext.Top) - (c.Bottom - c.Top)
		if c.Right-c.Left == w && c.Bottom-c.Top == ht {
			return
		}
		pSetWindowPos.Call(h, 0, 0, 0, uintptr(w+dw), uintptr(ht+dh),
			swpNoMove|swpNoZOrderFlag|swpNoActivate)
		time.Sleep(150 * time.Millisecond)
	}
}

// Déplace la fenêtre (sans la redimensionner) pour que sa partie VISIBLE commence
// exactement en (x,y) : on compense les bordures invisibles de Windows 10/11.
// La fenêtre passe devant les précédentes.
func placer(h uintptr, x, y int32) {
	// Windows 11 : coins carrés et pas de liseré gris -> aucun jour visible entre deux fenêtres.
	if retoucheBordures {
		coin := uint32(dwmwcpDoNotRound)
		pDwmSetWindowAttribute.Call(h, dwmwaCornerPreference, uintptr(unsafe.Pointer(&coin)), 4)
		bord := uint32(dwmwaColorNone)
		pDwmSetWindowAttribute.Call(h, dwmwaBorderColor, uintptr(unsafe.Pointer(&bord)), 4)
	}

	if z, _, _ := pIsZoomed.Call(h); z != 0 {
		pShowWindow.Call(h, swRestore)
	}
	if ic, _, _ := pIsIconic.Call(h); ic != 0 {
		pShowWindow.Call(h, swRestore)
	}
	for passe := 0; passe < 2; passe++ {
		var ext RECT
		pGetWindowRect.Call(h, uintptr(unsafe.Pointer(&ext)))
		vis := rectVisible(h)
		ml := vis.Left - ext.Left
		mt := vis.Top - ext.Top
		pSetWindowPos.Call(h, hwndTop,
			uintptr(x-ml), uintptr(y-mt), 0, 0,
			swpNoSize|swpNoActivate)
	}
}

// ---------- Écrans ----------

var (
	ecrans    []MONITORINFO
	monCbProc = syscall.NewCallback(func(hMon, hdc, lprc, lp uintptr) uintptr {
		var mi MONITORINFO
		mi.CbSize = uint32(unsafe.Sizeof(mi))
		if r, _, _ := pGetMonitorInfoW.Call(hMon, uintptr(unsafe.Pointer(&mi))); r != 0 {
			ecrans = append(ecrans, mi)
		}
		return 1
	})
)

// Le plus grand écran (le 4K) ; à égalité, celui le plus à droite.
func choisirEcran(nom string) MONITORINFO {
	ecrans = nil
	pEnumDisplayMonitors.Call(0, 0, monCbProc, 0)
	for _, m := range ecrans {
		if nom != "" && m.nomEcran() == nom {
			return m
		}
	}
	if len(ecrans) == 0 {
		var mi MONITORINFO
		mi.RcMonitor = RECT{0, 0, 1920, 1080}
		mi.RcWork = mi.RcMonitor
		return mi
	}
	best := ecrans[0]
	aire := func(m MONITORINFO) int64 {
		return int64(m.RcMonitor.Right-m.RcMonitor.Left) * int64(m.RcMonitor.Bottom-m.RcMonitor.Top)
	}
	for _, m := range ecrans[1:] {
		if aire(m) > aire(best) || (aire(m) == aire(best) && m.RcMonitor.Left > best.RcMonitor.Left) {
			best = m
		}
	}
	return best
}

type grille struct {
	cols      int
	w, h      int32 // taille visible d'une fenêtre (inchangée)
	pasY      int32 // décalage vertical entre deux lignes
	ox, oy    int32
	compresse bool
}

// Rapport mesuré sur la disposition modèle (4 fenêtres) : chaque ligne descend
// de 57,7 % de la hauteur d'une fenêtre -> barre de titre, menu et écran du haut
// de la DS restent entièrement visibles, la ligne suivante ne cache que l'écran du bas.

// Lignes de fenêtres collées côte à côte, en taille d'origine.
// Les lignes paires (2, 4, ...) sont décalées vers la droite d'une demi-fenêtre.
// Chaque nouvelle ligne passe devant la précédente et ne cache que son écran du bas.
func calculerGrille(n, parLigne int, w0, h0 int32, zone RECT, pasForce int32) grille {
	if parLigne > n {
		parLigne = n
	}
	lignes := (n + parLigne - 1) / parLigne
	H := zone.Bottom - zone.Top
	g := grille{cols: parLigne, w: w0, h: h0, ox: zone.Left, oy: zone.Top}
	g.pasY = int32(float64(h0)*emu.rapportPas + 0.5)
	if pasForce > 0 {
		g.pasY = pasForce
	}
	// Si trop de lignes pour que l'écran du haut de la dernière reste visible, on resserre.
	if lignes > 1 && int32(lignes)*g.pasY > H {
		g.pasY = H / int32(lignes)
		g.compresse = true
	}
	return g
}

func (g grille) position(i int) (int32, int32) {
	ligne, col := i/g.cols, i%g.cols
	x := g.ox + int32(col)*g.w
	if emu.decalage && ligne%2 == 1 {
		x += g.w / 2
	}
	return x, g.oy + int32(ligne)*g.pasY
}
